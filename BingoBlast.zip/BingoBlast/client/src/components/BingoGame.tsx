import { useEffect, useState } from "react";
import { useBingo } from "../lib/stores/useBingo";
import { useAudio } from "../lib/stores/useAudio";
import BingoBoard from "./BingoBoard";
import AIOpponent from "./AIOpponent";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";

interface BingoGameProps {
  onBack: () => void;
}

export default function BingoGame({ onBack }: BingoGameProps) {
  const { 
    gameState, 
    playerBoard, 
    aiBoard, 
    calledNumbers, 
    currentNumber, 
    isGameActive,
    winner,
    startGame,
    callNextNumber,
    checkWin
  } = useBingo();
  
  const { playHit, playSuccess } = useAudio();
  const [showConfetti, setShowConfetti] = useState(false);

  useEffect(() => {
    if (winner) {
      playSuccess();
      setShowConfetti(true);
      
      // Hide confetti after 3 seconds
      setTimeout(() => setShowConfetti(false), 3000);
    }
  }, [winner, playSuccess]);

  useEffect(() => {
    if (currentNumber && isGameActive) {
      playHit();
    }
  }, [currentNumber, isGameActive, playHit]);

  const handleStartGame = () => {
    startGame();
  };

  const handleCallNext = () => {
    if (isGameActive && !winner) {
      callNextNumber();
    }
  };

  const handleNewGame = () => {
    setShowConfetti(false);
    startGame();
  };

  return (
    <div className="w-full h-full bg-black relative overflow-hidden">
      {/* Confetti Effect */}
      {showConfetti && (
        <div className="fixed inset-0 z-50 pointer-events-none">
          {[...Array(50)].map((_, i) => (
            <div
              key={i}
              className="absolute w-2 h-2 bg-red-500 animate-bounce"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`,
                animationDuration: `${1 + Math.random()}s`
              }}
            />
          ))}
        </div>
      )}

      {/* Header */}
      <div className="flex justify-between items-center p-4 bg-gray-900">
        <Button
          onClick={onBack}
          className="bg-gray-700 hover:bg-gray-600 text-white rounded-lg px-4 py-2"
        >
          ← Back
        </Button>
        
        <h1 className="text-2xl font-bold text-white">Bingo VS AI</h1>
        
        <div className="flex items-center space-x-2">
          <Badge variant="outline" className="text-white border-white">
            Called: {calledNumbers.length}/25
          </Badge>
        </div>
      </div>

      {/* Game Content */}
      <div className="flex-1 p-4 space-y-4">
        {/* Current Number Display */}
        {currentNumber && (
          <Card className="bg-red-600 border-red-500 p-6 text-center">
            <div className="text-white">
              <p className="text-lg font-semibold mb-2">Current Number</p>
              <div className="text-6xl font-black bg-white text-red-600 rounded-full w-20 h-20 flex items-center justify-center mx-auto">
                {currentNumber}
              </div>
            </div>
          </Card>
        )}

        {/* Game Boards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Player Board */}
          <div className="space-y-4">
            <h2 className="text-xl font-bold text-white text-center">Your Board</h2>
            <BingoBoard 
              board={playerBoard} 
              calledNumbers={calledNumbers}
              isWinner={winner === 'player'}
            />
          </div>

          {/* AI Board */}
          <div className="space-y-4">
            <h2 className="text-xl font-bold text-white text-center">AI Opponent</h2>
            <AIOpponent 
              board={aiBoard}
              calledNumbers={calledNumbers}
              isWinner={winner === 'ai'}
              currentNumber={currentNumber}
            />
          </div>
        </div>

        {/* Game Controls */}
        <div className="flex justify-center space-x-4">
          {gameState === 'waiting' && (
            <Button
              onClick={handleStartGame}
              className="bg-red-600 hover:bg-red-700 text-white px-8 py-3 text-lg font-bold rounded-xl"
            >
              Start Game
            </Button>
          )}

          {gameState === 'playing' && !winner && (
            <Button
              onClick={handleCallNext}
              className="bg-green-600 hover:bg-green-700 text-white px-8 py-3 text-lg font-bold rounded-xl"
              disabled={calledNumbers.length >= 25}
            >
              Call Next Number
            </Button>
          )}

          {winner && (
            <div className="text-center space-y-4">
              <div className="text-3xl font-bold text-white mb-4">
                {winner === 'player' ? '🎉 You Win!' : '🤖 AI Wins!'}
              </div>
              <Button
                onClick={handleNewGame}
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 text-lg font-bold rounded-xl"
              >
                New Game
              </Button>
            </div>
          )}
        </div>

        {/* Called Numbers History */}
        {calledNumbers.length > 0 && (
          <Card className="bg-gray-800 p-4">
            <h3 className="text-white font-bold mb-3">Called Numbers:</h3>
            <div className="flex flex-wrap gap-2">
              {calledNumbers.map((num) => (
                <Badge
                  key={num}
                  variant="secondary"
                  className="bg-gray-600 text-white"
                >
                  {num}
                </Badge>
              ))}
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
