import { useEffect, useState } from "react";
import { useBingo } from "../lib/stores/useBingo";
import { useAudio } from "../lib/stores/useAudio";
import { ArrowLeft, Volume2, VolumeX } from "lucide-react";
import AIBot from "./AIBot";

interface GameBoardProps {
  onBackToHome: () => void;
}

export default function GameBoard({ onBackToHome }: GameBoardProps) {
  const {
    gamePhase,
    playerBoard,
    aiBoard,
    calledNumbers,
    currentNumber,
    gameResult,
    playerMarked,
    aiMarked,
    startGame,
    markNumber,
    nextNumber
  } = useBingo();

  const { isMuted, toggleMute, playHit, playSuccess } = useAudio();
  const [showConfetti, setShowConfetti] = useState(false);
  const [autoCallEnabled, setAutoCallEnabled] = useState(false);

  // Auto-start game when component mounts
  useEffect(() => {
    if (gamePhase === 'waiting') {
      startGame();
    }
  }, [gamePhase, startGame]);

  // Auto-call numbers when game is active
  useEffect(() => {
    if (gamePhase === 'playing' && autoCallEnabled) {
      const timer = setTimeout(() => {
        nextNumber();
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [gamePhase, currentNumber, autoCallEnabled, nextNumber]);

  // Handle game result
  useEffect(() => {
    if (gameResult) {
      if (gameResult.winner === 'player') {
        playSuccess();
        setShowConfetti(true);
        setTimeout(() => setShowConfetti(false), 5000);
      } else {
        playHit();
      }
    }
  }, [gameResult, playSuccess, playHit]);

  const handleCellClick = (number: number) => {
    if (gamePhase === 'playing' && calledNumbers.includes(number)) {
      markNumber(number, 'player');
      playHit();
    }
  };

  const handleNextNumber = () => {
    if (gamePhase === 'playing') {
      nextNumber();
    }
  };

  const renderBoard = (board: number[][], isPlayer: boolean = false) => {
    const markedNumbers = isPlayer ? playerMarked : aiMarked;
    
    return (
      <div className="grid grid-cols-5 gap-1 sm:gap-2 p-4 bg-gray-800 rounded-xl border-4 border-gray-600">
        {board.map((row, rowIndex) =>
          row.map((number, colIndex) => {
            const isCalled = calledNumbers.includes(number);
            const isMarked = markedNumbers.has(number);
            
            return (
              <div
                key={`${rowIndex}-${colIndex}`}
                onClick={isPlayer ? () => handleCellClick(number) : undefined}
                className={`bingo-cell ${isCalled ? 'called' : ''} ${isMarked ? 'marked' : ''} 
                           ${isPlayer ? 'cursor-pointer hover:scale-105' : 'cursor-default'}`}
              >
                {number}
              </div>
            );
          })
        )}
      </div>
    );
  };

  return (
    <div className="w-full h-full bg-gradient-to-br from-gray-900 via-black to-gray-800 flex flex-col relative overflow-hidden">
      {/* Confetti */}
      {showConfetti && (
        <div className="confetti">
          {Array.from({ length: 50 }).map((_, i) => (
            <div
              key={i}
              className="absolute w-2 h-2 bg-red-500 animate-bounce"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`,
                animationDuration: `${1 + Math.random() * 2}s`
              }}
            />
          ))}
        </div>
      )}

      {/* Header */}
      <div className="flex justify-between items-center p-4 z-10">
        <button
          onClick={onBackToHome}
          className="cartoon-button w-12 h-12 flex items-center justify-center text-gray-800"
        >
          <ArrowLeft size={20} />
        </button>

        <div className="flex items-center space-x-4">
          <button
            onClick={toggleMute}
            className="cartoon-button w-12 h-12 flex items-center justify-center text-gray-800"
          >
            {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
          </button>
        </div>
      </div>

      {/* Game Status */}
      <div className="text-center p-4">
        {gamePhase === 'waiting' && (
          <div className="text-2xl font-bold text-white">Getting Ready...</div>
        )}
        
        {gamePhase === 'playing' && (
          <div className="space-y-2">
            <div className="text-lg text-gray-300">Current Number</div>
            <div className="text-4xl font-bold text-red-500 fredoka bounce-in">
              {currentNumber || 'Starting...'}
            </div>
            <div className="text-sm text-gray-400">
              Called: {calledNumbers.length} / 25
            </div>
          </div>
        )}
        
        {gamePhase === 'finished' && gameResult && (
          <div className="space-y-2">
            <div className={`text-3xl font-bold fredoka ${gameResult.winner === 'player' ? 'text-green-400' : 'text-red-400'}`}>
              {gameResult.winner === 'player' ? '🎉 YOU WIN! 🎉' : '😔 AI WINS 😔'}
            </div>
            <div className="text-lg text-gray-300">
              {gameResult.pattern} - {gameResult.winner === 'player' ? 'BINGO!' : 'Better luck next time!'}
            </div>
          </div>
        )}
      </div>

      {/* Game Controls */}
      {gamePhase === 'playing' && (
        <div className="flex justify-center space-x-4 p-4">
          <button
            onClick={handleNextNumber}
            className="cartoon-button-red px-6 py-3 fredoka text-lg font-bold"
          >
            Call Next Number
          </button>
          
          <button
            onClick={() => setAutoCallEnabled(!autoCallEnabled)}
            className={`cartoon-button px-6 py-3 fredoka text-lg font-bold ${autoCallEnabled ? 'bg-green-500' : ''}`}
          >
            {autoCallEnabled ? 'Auto: ON' : 'Auto: OFF'}
          </button>
        </div>
      )}

      {/* Game Boards */}
      <div className="flex-1 flex flex-col lg:flex-row items-center justify-center space-y-6 lg:space-y-0 lg:space-x-8 p-4">
        {/* Player Board */}
        <div className="flex flex-col items-center space-y-4">
          <h2 className="text-xl font-bold text-white fredoka">YOUR BOARD</h2>
          {renderBoard(playerBoard, true)}
        </div>

        {/* AI Bot */}
        <div className="flex flex-col items-center space-y-4">
          <AIBot 
            isWinner={gameResult?.winner === 'ai'}
            isPlaying={gamePhase === 'playing'}
            currentNumber={currentNumber}
          />
        </div>

        {/* AI Board */}
        <div className="flex flex-col items-center space-y-4">
          <h2 className="text-xl font-bold text-white fredoka">AI BOARD</h2>
          {renderBoard(aiBoard)}
        </div>
      </div>

      {/* Called Numbers History */}
      <div className="p-4 bg-gray-800 border-t-2 border-gray-600">
        <div className="text-center">
          <div className="text-sm text-gray-400 mb-2">Called Numbers</div>
          <div className="flex flex-wrap justify-center gap-2 max-h-20 overflow-y-auto">
            {calledNumbers.map((number, index) => (
              <span
                key={number}
                className={`w-8 h-8 flex items-center justify-center bg-red-500 text-white rounded-full text-xs font-bold
                           ${index === calledNumbers.length - 1 ? 'ring-2 ring-yellow-400' : ''}`}
              >
                {number}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Restart Button */}
      {gamePhase === 'finished' && (
        <div className="flex justify-center p-4">
          <button
            onClick={() => startGame()}
            className="cartoon-button-red px-8 py-4 fredoka text-xl font-bold"
          >
            Play Again
          </button>
        </div>
      )}
    </div>
  );
}
