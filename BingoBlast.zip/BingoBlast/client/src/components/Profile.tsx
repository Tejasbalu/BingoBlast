import { useState } from "react";
import { useProfile } from "../lib/stores/useProfile";
import { ArrowLeft, Edit, Trophy, Target, TrendingUp } from "lucide-react";

interface ProfileProps {
  onBack: () => void;
}

export default function Profile({ onBack }: ProfileProps) {
  const { profile, updateProfile } = useProfile();
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({
    name: profile.name,
    age: profile.age.toString()
  });

  const handleSave = () => {
    updateProfile({
      name: editForm.name,
      age: parseInt(editForm.age) || 18
    });
    setIsEditing(false);
  };

  const winRatio = profile.matchesPlayed > 0 ? 
    Math.round((profile.matchesWon / profile.matchesPlayed) * 100) : 0;

  return (
    <div className="w-full h-full bg-gradient-to-br from-gray-900 via-black to-gray-800 flex flex-col overflow-hidden">
      {/* Header */}
      <div className="flex justify-between items-center p-4 border-b border-gray-700">
        <button
          onClick={onBack}
          className="cartoon-button w-12 h-12 flex items-center justify-center text-gray-800"
        >
          <ArrowLeft size={20} />
        </button>
        
        <h1 className="fredoka text-2xl font-bold text-white">Profile</h1>
        
        <button
          onClick={() => setIsEditing(!isEditing)}
          className="cartoon-button w-12 h-12 flex items-center justify-center text-gray-800"
        >
          <Edit size={20} />
        </button>
      </div>

      {/* Profile Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {/* Profile Avatar & Info */}
        <div className="flex flex-col items-center space-y-4">
          {/* Avatar */}
          <div className="w-24 h-24 rounded-full bg-gradient-to-br from-red-400 via-red-500 to-red-600 
                         flex items-center justify-center border-4 border-white shadow-xl">
            <span className="fredoka text-3xl font-bold text-white">
              {profile.name.charAt(0).toUpperCase()}
            </span>
          </div>

          {/* Name & Age */}
          {isEditing ? (
            <div className="space-y-4 w-full max-w-xs">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Name</label>
                <input
                  type="text"
                  value={editForm.name}
                  onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                  className="w-full px-4 py-2 bg-gray-800 border border-gray-600 rounded-lg text-white 
                           focus:outline-none focus:ring-2 focus:ring-red-500"
                  placeholder="Enter your name"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Age</label>
                <input
                  type="number"
                  value={editForm.age}
                  onChange={(e) => setEditForm({ ...editForm, age: e.target.value })}
                  className="w-full px-4 py-2 bg-gray-800 border border-gray-600 rounded-lg text-white 
                           focus:outline-none focus:ring-2 focus:ring-red-500"
                  placeholder="Enter your age"
                  min="1"
                  max="120"
                />
              </div>
              
              <div className="flex space-x-2">
                <button
                  onClick={handleSave}
                  className="flex-1 cartoon-button-red py-2 px-4 fredoka font-bold"
                >
                  Save
                </button>
                <button
                  onClick={() => setIsEditing(false)}
                  className="flex-1 cartoon-button py-2 px-4 fredoka font-bold text-gray-800"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <div className="text-center">
              <h2 className="fredoka text-2xl font-bold text-white">{profile.name}</h2>
              <p className="text-gray-400">Age: {profile.age}</p>
              <p className="text-sm text-gray-500 mt-1">Level: Beginner</p>
            </div>
          )}
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {/* Matches Played */}
          <div className="bg-gray-800 rounded-xl p-4 border-2 border-gray-600">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center">
                <Target size={24} className="text-white" />
              </div>
              <div>
                <div className="text-2xl font-bold text-white">{profile.matchesPlayed}</div>
                <div className="text-sm text-gray-400">Matches Played</div>
              </div>
            </div>
          </div>

          {/* Matches Won */}
          <div className="bg-gray-800 rounded-xl p-4 border-2 border-gray-600">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center">
                <Trophy size={24} className="text-white" />
              </div>
              <div>
                <div className="text-2xl font-bold text-white">{profile.matchesWon}</div>
                <div className="text-sm text-gray-400">Matches Won</div>
              </div>
            </div>
          </div>

          {/* Win Ratio */}
          <div className="bg-gray-800 rounded-xl p-4 border-2 border-gray-600">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center">
                <TrendingUp size={24} className="text-white" />
              </div>
              <div>
                <div className="text-2xl font-bold text-white">{winRatio}%</div>
                <div className="text-sm text-gray-400">Win Ratio</div>
              </div>
            </div>
          </div>
        </div>

        {/* Achievements */}
        <div className="bg-gray-800 rounded-xl p-4 border-2 border-gray-600">
          <h3 className="fredoka text-lg font-bold text-white mb-4">Achievements</h3>
          <div className="space-y-3">
            <div className="flex items-center space-x-3 p-2 bg-gray-700 rounded-lg">
              <div className="text-2xl">🎯</div>
              <div>
                <div className="text-white font-semibold">First Game</div>
                <div className="text-sm text-gray-400">Play your first Bingo game</div>
              </div>
              <div className={`ml-auto ${profile.matchesPlayed > 0 ? 'text-green-400' : 'text-gray-500'}`}>
                {profile.matchesPlayed > 0 ? '✓' : '○'}
              </div>
            </div>

            <div className="flex items-center space-x-3 p-2 bg-gray-700 rounded-lg">
              <div className="text-2xl">🏆</div>
              <div>
                <div className="text-white font-semibold">First Victory</div>
                <div className="text-sm text-gray-400">Win your first Bingo game</div>
              </div>
              <div className={`ml-auto ${profile.matchesWon > 0 ? 'text-green-400' : 'text-gray-500'}`}>
                {profile.matchesWon > 0 ? '✓' : '○'}
              </div>
            </div>

            <div className="flex items-center space-x-3 p-2 bg-gray-700 rounded-lg">
              <div className="text-2xl">🔥</div>
              <div>
                <div className="text-white font-semibold">Winning Streak</div>
                <div className="text-sm text-gray-400">Win 3 games in a row</div>
              </div>
              <div className="ml-auto text-gray-500">○</div>
            </div>
          </div>
        </div>

        {/* Account Section */}
        <div className="bg-gray-800 rounded-xl p-4 border-2 border-gray-600">
          <h3 className="fredoka text-lg font-bold text-white mb-4">Account</h3>
          <div className="space-y-3">
            <button className="w-full cartoon-button py-3 px-4 fredoka font-bold text-gray-800 text-left">
              Login & Earn Coins
            </button>
            <div className="text-sm text-gray-400 px-2">
              Connect your account to save progress and earn rewards!
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
