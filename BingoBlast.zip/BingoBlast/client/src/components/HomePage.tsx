import { useState } from "react";
import Logo from "./Logo";
import { User, Trophy, Menu } from "lucide-react";
import { MultiplayerIcon, CustomRoomIcon, VSAIIcon, ReferIcon } from "./CustomSVGIcons";

interface HomePageProps {
  onNavigate: (view: 'profile' | 'leaderboard' | 'menu' | 'multiplayer' | 'referral') => void;
  onStartGame: () => void;
}

export default function HomePage({ onNavigate, onStartGame }: HomePageProps) {
  const [hoveredButton, setHoveredButton] = useState<string | null>(null);

  const handleButtonClick = (action: string) => {
    // Play button click sound
    const audio = new Audio('/sounds/button-click.mp3');
    audio.volume = 0.3;
    audio.play().catch(() => {});

    switch (action) {
      case 'vs-ai':
        onStartGame();
        break;
      case 'multiplayer':
        onNavigate('multiplayer');
        break;
      case 'custom-rooms':
        onNavigate('multiplayer');
        break;
      case 'referral':
        onNavigate('referral');
        break;
      case 'profile':
        onNavigate('profile');
        break;
      case 'leaderboard':
        onNavigate('leaderboard');
        break;
      case 'menu':
        onNavigate('menu');
        break;
    }
  };

  return (
    <div className="w-full h-full bg-gradient-to-br from-gray-900 via-black to-gray-800 flex flex-col relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 left-10 w-32 h-32 bg-red-500 rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 right-10 w-24 h-24 bg-white rounded-full blur-2xl"></div>
        <div className="absolute bottom-20 left-1/4 w-40 h-40 bg-gray-400 rounded-full blur-3xl"></div>
      </div>

      {/* Header */}
      <div className="flex justify-between items-center p-4 z-10">
        {/* Profile Button */}
        <button
          onClick={() => handleButtonClick('profile')}
          onMouseEnter={() => setHoveredButton('profile')}
          onMouseLeave={() => setHoveredButton(null)}
          className={`cartoon-button w-16 h-16 flex items-center justify-center text-gray-800 glossy
                     ${hoveredButton === 'profile' ? 'pulse-glow' : ''}`}
        >
          <User size={24} />
        </button>

        {/* Header Actions */}
        <div className="flex space-x-4">
          <button
            onClick={() => handleButtonClick('leaderboard')}
            onMouseEnter={() => setHoveredButton('leaderboard')}
            onMouseLeave={() => setHoveredButton(null)}
            className={`cartoon-button w-16 h-16 flex items-center justify-center text-gray-800 glossy
                       ${hoveredButton === 'leaderboard' ? 'pulse-glow' : ''}`}
          >
            <Trophy size={24} />
          </button>
          
          <button
            onClick={() => handleButtonClick('menu')}
            onMouseEnter={() => setHoveredButton('menu')}
            onMouseLeave={() => setHoveredButton(null)}
            className={`cartoon-button w-16 h-16 flex items-center justify-center text-gray-800 glossy
                       ${hoveredButton === 'menu' ? 'pulse-glow' : ''}`}
          >
            <Menu size={24} />
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col items-center justify-center p-4 space-y-8">
        {/* Logo */}
        <div className="mb-4">
          <Logo size="large" animated={true} />
        </div>

        {/* Game Mode Buttons */}
        <div className="flex flex-col space-y-6 w-full max-w-xs">
          {/* Vs AI Button - Primary */}
          <button
            onClick={() => handleButtonClick('vs-ai')}
            onMouseEnter={() => setHoveredButton('vs-ai')}
            onMouseLeave={() => setHoveredButton(null)}
            className={`cartoon-button-red h-16 px-8 flex items-center justify-center space-x-3 glossy fredoka text-xl font-bold
                       ${hoveredButton === 'vs-ai' ? 'pulse-glow' : ''}`}
          >
            <VSAIIcon size={28} animated={hoveredButton === 'vs-ai'} />
            <span>VS AI</span>
          </button>

          {/* Multiplayer Button */}
          <button
            onClick={() => handleButtonClick('multiplayer')}
            onMouseEnter={() => setHoveredButton('multiplayer')}
            onMouseLeave={() => setHoveredButton(null)}
            className={`cartoon-button h-14 px-8 flex items-center justify-center space-x-3 glossy fredoka text-lg font-bold text-gray-800
                       ${hoveredButton === 'multiplayer' ? 'pulse-glow' : ''}`}
          >
            <MultiplayerIcon size={24} animated={hoveredButton === 'multiplayer'} />
            <span>Multiplayer</span>
          </button>

          {/* Custom Rooms Button */}
          <button
            onClick={() => handleButtonClick('custom-rooms')}
            onMouseEnter={() => setHoveredButton('custom-rooms')}
            onMouseLeave={() => setHoveredButton(null)}
            className={`cartoon-button h-14 px-8 flex items-center justify-center space-x-3 glossy fredoka text-lg font-bold text-gray-800
                       ${hoveredButton === 'custom-rooms' ? 'pulse-glow' : ''}`}
          >
            <CustomRoomIcon size={24} animated={hoveredButton === 'custom-rooms'} />
            <span>Custom Rooms</span>
          </button>

          {/* Refer & Earn Button */}
          <button
            onClick={() => handleButtonClick('referral')}
            onMouseEnter={() => setHoveredButton('referral')}
            onMouseLeave={() => setHoveredButton(null)}
            className={`cartoon-button h-12 px-8 flex items-center justify-center space-x-3 glossy fredoka text-md font-bold text-gray-800
                       ${hoveredButton === 'referral' ? 'pulse-glow' : ''}`}
          >
            <ReferIcon size={20} animated={hoveredButton === 'referral'} />
            <span>Refer & Earn</span>
          </button>
        </div>

        {/* Footer */}
        <div className="mt-8 text-center">
          <p className="text-gray-400 text-sm">
            Made with ❤️ by TiRRuS
          </p>
        </div>
      </div>
    </div>
  );
}
