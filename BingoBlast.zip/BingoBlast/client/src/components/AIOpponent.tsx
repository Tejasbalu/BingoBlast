import { useEffect, useState } from "react";
import { Card } from "./ui/card";

interface AIOpponentProps {
  board: number[][];
  calledNumbers: number[];
  isWinner?: boolean;
  currentNumber?: number | null;
}

const AI_REACTIONS = [
  "🤔 Thinking...",
  "😊 Not bad!",
  "😤 So close!",
  "🎯 Nice one!",
  "😅 Almost there!",
  "🤞 Come on!",
  "😎 Piece of cake!",
  "😬 Getting nervous...",
];

export default function AIOpponent({ board, calledNumbers, isWinner = false, currentNumber }: AIOpponentProps) {
  const [reaction, setReaction] = useState("🤖 Ready to play!");
  const [animatingCell, setAnimatingCell] = useState<number | null>(null);

  const isCalled = (number: number) => calledNumbers.includes(number);

  useEffect(() => {
    if (currentNumber && board.flat().includes(currentNumber)) {
      // Show reaction when AI has the called number
      const randomReaction = AI_REACTIONS[Math.floor(Math.random() * AI_REACTIONS.length)];
      setReaction(randomReaction);
      setAnimatingCell(currentNumber);
      
      // Reset animation after a short delay
      setTimeout(() => {
        setAnimatingCell(null);
      }, 1000);
    } else if (currentNumber) {
      // Show different reaction when AI doesn't have the number
      setReaction("😔 Missed that one!");
    }
  }, [currentNumber, board]);

  useEffect(() => {
    if (isWinner) {
      setReaction("🎉 I WIN! Good game!");
    }
  }, [isWinner]);

  return (
    <div className="space-y-4">
      {/* AI Avatar and Reaction */}
      <Card className="bg-gray-800 p-4">
        <div className="flex items-center space-x-4">
          <div className="text-4xl">🤖</div>
          <div className="flex-1">
            <h3 className="text-white font-bold">AI Bot</h3>
            <p className="text-gray-300 text-sm animate-pulse">{reaction}</p>
          </div>
        </div>
      </Card>

      {/* AI Board */}
      <Card 
        className={`p-4 bg-gray-800 border-2 transition-all duration-300 ${
          isWinner 
            ? 'border-red-500 shadow-lg shadow-red-500/50' 
            : 'border-gray-600'
        }`}
      >
        <div className="grid grid-cols-5 gap-2">
          {board.flat().map((number, index) => {
            const called = isCalled(number);
            const row = Math.floor(index / 5);
            const col = index % 5;
            const isCenter = row === 2 && col === 2;
            const isAnimating = animatingCell === number;
            
            return (
              <div
                key={index}
                className={`
                  aspect-square flex items-center justify-center rounded-lg font-bold text-lg
                  transition-all duration-500 transform
                  ${called || isCenter
                    ? 'bg-red-600 text-white shadow-lg' 
                    : 'bg-gray-200 text-gray-800'
                  }
                  ${isCenter ? 'bg-red-500' : ''}
                  ${isAnimating ? 'scale-110 animate-pulse' : ''}
                `}
                style={{
                  boxShadow: called || isCenter 
                    ? '0 4px 8px rgba(239, 68, 68, 0.3), inset 0 1px 0 rgba(255,255,255,0.2)' 
                    : '0 2px 4px rgba(0,0,0,0.1), inset 0 1px 0 rgba(255,255,255,0.8)'
                }}
              >
                {isCenter ? 'FREE' : number}
              </div>
            );
          })}
        </div>
        
        {isWinner && (
          <div className="mt-4 text-center">
            <div className="text-red-400 font-bold text-xl animate-pulse">
              🤖 AI WINS! 🤖
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}
