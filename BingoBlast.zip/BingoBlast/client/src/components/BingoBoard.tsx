import { Card } from "./ui/card";

interface BingoBoardProps {
  board: number[][];
  calledNumbers: number[];
  isWinner?: boolean;
}

export default function BingoBoard({ board, calledNumbers, isWinner = false }: BingoBoardProps) {
  const isCalled = (number: number) => calledNumbers.includes(number);

  return (
    <Card 
      className={`p-4 bg-gray-800 border-2 transition-all duration-300 ${
        isWinner 
          ? 'border-green-500 shadow-lg shadow-green-500/50' 
          : 'border-gray-600'
      }`}
    >
      <div className="grid grid-cols-5 gap-2">
        {board.flat().map((number, index) => {
          const called = isCalled(number);
          const row = Math.floor(index / 5);
          const col = index % 5;
          const isCenter = row === 2 && col === 2;
          
          return (
            <div
              key={index}
              className={`
                aspect-square flex items-center justify-center rounded-lg font-bold text-lg
                transition-all duration-300 transform hover:scale-105
                ${called || isCenter
                  ? 'bg-red-600 text-white shadow-lg scale-95' 
                  : 'bg-gray-200 text-gray-800 hover:bg-gray-300'
                }
                ${isCenter ? 'bg-red-500' : ''}
              `}
              style={{
                boxShadow: called || isCenter 
                  ? '0 4px 8px rgba(239, 68, 68, 0.3), inset 0 1px 0 rgba(255,255,255,0.2)' 
                  : '0 2px 4px rgba(0,0,0,0.1), inset 0 1px 0 rgba(255,255,255,0.8)'
              }}
            >
              {isCenter ? 'FREE' : number}
            </div>
          );
        })}
      </div>
      
      {isWinner && (
        <div className="mt-4 text-center">
          <div className="text-green-400 font-bold text-xl animate-pulse">
            🎉 BINGO! 🎉
          </div>
        </div>
      )}
    </Card>
  );
}
