import { useState } from "react";
import { useProfile } from "../lib/stores/useProfile";
import { ArrowLeft, Copy, Check, Share2, MessageCircle, Send } from "lucide-react";

interface ReferralSystemProps {
  onBack: () => void;
}

export default function ReferralSystem({ onBack }: ReferralSystemProps) {
  const { profile, addCoins } = useProfile();
  const [copiedCode, setCopiedCode] = useState(false);
  const [shareMethod, setShareMethod] = useState<string | null>(null);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(profile.inviteCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleShare = (method: string) => {
    const shareText = `🎲 Join me in this awesome Bingo game! Use my invite code: ${profile.inviteCode}\n\nDownload now and earn bonus coins when you play your first game!`;
    const shareUrl = window.location.href;

    switch (method) {
      case 'whatsapp':
        window.open(`https://wa.me/?text=${encodeURIComponent(shareText + '\n' + shareUrl)}`, '_blank');
        break;
      case 'telegram':
        window.open(`https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareText)}`, '_blank');
        break;
      case 'sms':
        window.open(`sms:?body=${encodeURIComponent(shareText + '\n' + shareUrl)}`, '_blank');
        break;
      case 'email':
        window.open(`mailto:?subject=Join me in Bingo!&body=${encodeURIComponent(shareText + '\n' + shareUrl)}`, '_blank');
        break;
      case 'native':
        if (navigator.share) {
          navigator.share({
            title: 'Bingo Game - Join Me!',
            text: shareText,
            url: shareUrl
          });
        }
        break;
    }
    
    setShareMethod(method);
    setTimeout(() => setShareMethod(null), 1000);
  };

  const shareOptions = [
    { id: 'whatsapp', name: 'WhatsApp', icon: '📱', color: 'bg-green-500' },
    { id: 'telegram', name: 'Telegram', icon: '✈️', color: 'bg-blue-500' },
    { id: 'sms', name: 'SMS', icon: '💬', color: 'bg-purple-500' },
    { id: 'email', name: 'Email', icon: '📧', color: 'bg-red-500' },
    { id: 'native', name: 'More', icon: '📤', color: 'bg-gray-500' }
  ];

  const mockReferrals = [
    { name: 'Alex', date: '2 days ago', coins: 100, status: 'completed' },
    { name: 'Sarah', date: '1 week ago', coins: 100, status: 'completed' },
    { name: 'Mike', date: '2 weeks ago', coins: 50, status: 'pending' }
  ];

  return (
    <div className="w-full h-full bg-gradient-to-br from-gray-900 via-black to-gray-800 flex flex-col overflow-hidden">
      {/* Header */}
      <div className="flex justify-between items-center p-4 border-b border-gray-700">
        <button
          onClick={onBack}
          className="cartoon-button w-12 h-12 flex items-center justify-center text-gray-800"
        >
          <ArrowLeft size={20} />
        </button>
        
        <h1 className="fredoka text-2xl font-bold text-white">Refer & Earn</h1>
        
        <div className="w-12 h-12"></div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {/* Invite Code Section */}
        <div className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl p-6 text-center">
          <div className="text-white mb-4">
            <h2 className="fredoka text-2xl font-bold mb-2">Your Invite Code</h2>
            <p className="text-purple-100">Share with friends and earn coins!</p>
          </div>
          
          <div className="bg-white rounded-lg p-4 mb-4">
            <div className="fredoka text-3xl font-bold text-gray-800 tracking-wider">
              {profile.inviteCode}
            </div>
          </div>
          
          <button
            onClick={handleCopyCode}
            className="cartoon-button px-6 py-3 fredoka font-bold text-gray-800 flex items-center space-x-2 mx-auto"
          >
            {copiedCode ? <Check size={20} /> : <Copy size={20} />}
            <span>{copiedCode ? 'Copied!' : 'Copy Code'}</span>
          </button>
        </div>

        {/* How it Works */}
        <div className="bg-gray-800 rounded-xl p-4 border-2 border-gray-600">
          <h3 className="fredoka text-lg font-bold text-white mb-4">How it Works</h3>
          <div className="space-y-3">
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold text-sm">1</div>
              <div>
                <div className="text-white font-semibold">Share your code</div>
                <div className="text-sm text-gray-400">Send your invite code to friends</div>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white font-bold text-sm">2</div>
              <div>
                <div className="text-white font-semibold">Friend joins</div>
                <div className="text-sm text-gray-400">They enter your code when signing up</div>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center text-white font-bold text-sm">3</div>
              <div>
                <div className="text-white font-semibold">Both earn coins</div>
                <div className="text-sm text-gray-400">You both get 100 coins when they play their first game</div>
              </div>
            </div>
          </div>
        </div>

        {/* Share Options */}
        <div className="bg-gray-800 rounded-xl p-4 border-2 border-gray-600">
          <h3 className="fredoka text-lg font-bold text-white mb-4">Share via</h3>
          <div className="grid grid-cols-3 gap-3">
            {shareOptions.map((option) => (
              <button
                key={option.id}
                onClick={() => handleShare(option.id)}
                className={`${option.color} rounded-lg p-4 text-white transition-all duration-200 hover:scale-105
                           ${shareMethod === option.id ? 'scale-95' : ''}`}
              >
                <div className="text-2xl mb-2">{option.icon}</div>
                <div className="text-sm font-semibold">{option.name}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Earnings Summary */}
        <div className="bg-gray-800 rounded-xl p-4 border-2 border-gray-600">
          <h3 className="fredoka text-lg font-bold text-white mb-4">Your Earnings</h3>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-yellow-400">{mockReferrals.length}</div>
              <div className="text-sm text-gray-400">Referrals</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-green-400">
                {mockReferrals.filter(r => r.status === 'completed').reduce((sum, r) => sum + r.coins, 0)}
              </div>
              <div className="text-sm text-gray-400">Coins Earned</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-blue-400">
                {mockReferrals.filter(r => r.status === 'pending').reduce((sum, r) => sum + r.coins, 0)}
              </div>
              <div className="text-sm text-gray-400">Pending</div>
            </div>
          </div>
        </div>

        {/* Referral History */}
        <div className="bg-gray-800 rounded-xl p-4 border-2 border-gray-600">
          <h3 className="fredoka text-lg font-bold text-white mb-4">Recent Referrals</h3>
          {mockReferrals.length > 0 ? (
            <div className="space-y-3">
              {mockReferrals.map((referral, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full 
                                   flex items-center justify-center text-white font-bold">
                      {referral.name.charAt(0)}
                    </div>
                    <div>
                      <div className="text-white font-semibold">{referral.name}</div>
                      <div className="text-sm text-gray-400">{referral.date}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`font-bold ${referral.status === 'completed' ? 'text-green-400' : 'text-yellow-400'}`}>
                      +{referral.coins} coins
                    </div>
                    <div className={`text-xs ${referral.status === 'completed' ? 'text-green-400' : 'text-yellow-400'}`}>
                      {referral.status}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <div className="text-gray-400 mb-2">No referrals yet</div>
              <div className="text-sm text-gray-500">Start sharing your code to earn coins!</div>
            </div>
          )}
        </div>

        {/* Special Offers */}
        <div className="bg-gradient-to-r from-yellow-600 to-orange-600 rounded-xl p-4 text-center">
          <h3 className="fredoka text-lg font-bold text-white mb-2">Limited Time Bonus!</h3>
          <p className="text-yellow-100 mb-3">
            Refer 5 friends this week and get an extra 500 coins!
          </p>
          <div className="bg-white rounded-lg p-2">
            <div className="text-gray-800 font-bold">
              Progress: {mockReferrals.filter(r => r.status === 'completed').length}/5
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}