import React from 'react';

interface SVGIconProps {
  size?: number;
  className?: string;
  animated?: boolean;
}

export const MultiplayerIcon = ({ size = 24, className = '', animated = false }: SVGIconProps) => (
  <svg 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none" 
    className={`${className} ${animated ? 'animated-svg' : ''}`}
  >
    <defs>
      <linearGradient id="multiplayerGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#3b82f6" />
        <stop offset="50%" stopColor="#8b5cf6" />
        <stop offset="100%" stopColor="#ec4899" />
      </linearGradient>
    </defs>
    
    {/* Players */}
    <circle cx="7" cy="8" r="3" fill="url(#multiplayerGrad)" />
    <circle cx="17" cy="8" r="3" fill="url(#multiplayerGrad)" />
    
    {/* Bodies */}
    <path d="M2 20v-2c0-2.2 1.8-4 4-4h2c2.2 0 4 1.8 4 4v2" fill="url(#multiplayerGrad)" />
    <path d="M12 20v-2c0-2.2 1.8-4 4-4h2c2.2 0 4 1.8 4 4v2" fill="url(#multiplayerGrad)" />
    
    {/* Connection lines */}
    <path d="M10 12h4" stroke="url(#multiplayerGrad)" strokeWidth="2" strokeLinecap="round" />
    
    {animated && (
      <circle cx="12" cy="12" r="1" fill="#fff">
        <animate attributeName="r" values="1;3;1" dur="2s" repeatCount="indefinite" />
        <animate attributeName="opacity" values="1;0.3;1" dur="2s" repeatCount="indefinite" />
      </circle>
    )}
  </svg>
);

export const CustomRoomIcon = ({ size = 24, className = '', animated = false }: SVGIconProps) => (
  <svg 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none" 
    className={`${className} ${animated ? 'animated-svg' : ''}`}
  >
    <defs>
      <linearGradient id="roomGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#10b981" />
        <stop offset="50%" stopColor="#06b6d4" />
        <stop offset="100%" stopColor="#3b82f6" />
      </linearGradient>
    </defs>
    
    {/* House structure */}
    <path d="M3 21h18V9l-9-7-9 7v12z" fill="url(#roomGrad)" />
    <path d="M9 21v-6h6v6" fill="#374151" />
    
    {/* Door */}
    <rect x="11" y="17" width="2" height="4" fill="#1f2937" />
    
    {/* Windows */}
    <rect x="6" y="13" width="2" height="2" fill="#fbbf24" />
    <rect x="16" y="13" width="2" height="2" fill="#fbbf24" />
    
    {/* Roof */}
    <path d="M2 9l10-8 10 8" stroke="#dc2626" strokeWidth="2" fill="none" />
    
    {/* Chimney smoke */}
    {animated && (
      <g>
        <circle cx="18" cy="6" r="1" fill="#9ca3af">
          <animate attributeName="cy" values="6;2;6" dur="3s" repeatCount="indefinite" />
          <animate attributeName="opacity" values="1;0;1" dur="3s" repeatCount="indefinite" />
        </circle>
        <circle cx="19" cy="7" r="0.8" fill="#9ca3af">
          <animate attributeName="cy" values="7;3;7" dur="3.5s" repeatCount="indefinite" />
          <animate attributeName="opacity" values="1;0;1" dur="3.5s" repeatCount="indefinite" />
        </circle>
      </g>
    )}
  </svg>
);

export const VSAIIcon = ({ size = 24, className = '', animated = false }: SVGIconProps) => (
  <svg 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none" 
    className={`${className} ${animated ? 'animated-svg' : ''}`}
  >
    <defs>
      <linearGradient id="aiGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#ef4444" />
        <stop offset="50%" stopColor="#f59e0b" />
        <stop offset="100%" stopColor="#eab308" />
      </linearGradient>
    </defs>
    
    {/* Robot head */}
    <rect x="8" y="6" width="8" height="8" rx="2" fill="url(#aiGrad)" />
    
    {/* Eyes */}
    <circle cx="10" cy="9" r="1" fill="#fff" />
    <circle cx="14" cy="9" r="1" fill="#fff" />
    
    {/* Mouth */}
    <rect x="10" y="12" width="4" height="1" rx="0.5" fill="#fff" />
    
    {/* Antennas */}
    <line x1="9" y1="6" x2="9" y2="4" stroke="url(#aiGrad)" strokeWidth="2" strokeLinecap="round" />
    <line x1="15" y1="6" x2="15" y2="4" stroke="url(#aiGrad)" strokeWidth="2" strokeLinecap="round" />
    <circle cx="9" cy="4" r="1" fill="#fbbf24" />
    <circle cx="15" cy="4" r="1" fill="#fbbf24" />
    
    {/* Body */}
    <rect x="9" y="14" width="6" height="6" rx="1" fill="url(#aiGrad)" />
    
    {/* Arms */}
    <rect x="6" y="15" width="2" height="4" rx="1" fill="url(#aiGrad)" />
    <rect x="16" y="15" width="2" height="4" rx="1" fill="url(#aiGrad)" />
    
    {animated && (
      <g>
        <circle cx="10" cy="9" r="0.5" fill="#ef4444">
          <animate attributeName="opacity" values="1;0.3;1" dur="1.5s" repeatCount="indefinite" />
        </circle>
        <circle cx="14" cy="9" r="0.5" fill="#ef4444">
          <animate attributeName="opacity" values="1;0.3;1" dur="1.5s" repeatCount="indefinite" />
        </circle>
      </g>
    )}
  </svg>
);

export const ReferIcon = ({ size = 24, className = '', animated = false }: SVGIconProps) => (
  <svg 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none" 
    className={`${className} ${animated ? 'animated-svg' : ''}`}
  >
    <defs>
      <linearGradient id="referGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#8b5cf6" />
        <stop offset="50%" stopColor="#ec4899" />
        <stop offset="100%" stopColor="#f59e0b" />
      </linearGradient>
    </defs>
    
    {/* Gift box */}
    <rect x="5" y="8" width="14" height="10" rx="2" fill="url(#referGrad)" />
    
    {/* Ribbon vertical */}
    <rect x="11" y="8" width="2" height="10" fill="#fbbf24" />
    
    {/* Ribbon horizontal */}
    <rect x="5" y="12" width="14" height="2" fill="#fbbf24" />
    
    {/* Bow */}
    <path d="M8 8c0-2 2-4 4-4s4 2 4 4" fill="#dc2626" />
    <circle cx="12" cy="6" r="1.5" fill="#dc2626" />
    
    {/* Sparkles */}
    {animated && (
      <g>
        <circle cx="7" cy="6" r="0.5" fill="#fbbf24">
          <animate attributeName="opacity" values="0;1;0" dur="2s" repeatCount="indefinite" />
        </circle>
        <circle cx="17" cy="7" r="0.5" fill="#fbbf24">
          <animate attributeName="opacity" values="0;1;0" dur="2.5s" repeatCount="indefinite" />
        </circle>
        <circle cx="6" cy="15" r="0.5" fill="#fbbf24">
          <animate attributeName="opacity" values="0;1;0" dur="1.8s" repeatCount="indefinite" />
        </circle>
      </g>
    )}
  </svg>
);