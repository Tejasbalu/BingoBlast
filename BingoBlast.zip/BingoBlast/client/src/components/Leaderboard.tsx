import { useState } from "react";
import { ArrowLeft, Trophy, Globe, MapPin, Calendar, Clock } from "lucide-react";

interface LeaderboardProps {
  onBack: () => void;
}

type LeaderboardTab = 'global' | 'country';
type LeaderboardFilter = 'weekly' | 'alltime';

interface LeaderboardEntry {
  rank: number;
  name: string;
  earnings: number;
  gamesWon: number;
  winRate: number;
  country: string;
}

// Mock leaderboard data
const mockLeaderboard: LeaderboardEntry[] = [
  { rank: 1, name: "BingoMaster", earnings: 15420, gamesWon: 234, winRate: 87, country: "USA" },
  { rank: 2, name: "NumberCruncher", earnings: 13890, gamesWon: 198, winRate: 82, country: "Canada" },
  { rank: 3, name: "LuckyPlayer", earnings: 12350, gamesWon: 176, winRate: 79, country: "UK" },
  { rank: 4, name: "BingoQueen", earnings: 11200, gamesWon: 165, winRate: 75, country: "Australia" },
  { rank: 5, name: "NumberWiz", earnings: 10890, gamesWon: 154, winRate: 73, country: "Germany" },
  { rank: 6, name: "GameChamp", earnings: 9750, gamesWon: 142, winRate: 71, country: "France" },
  { rank: 7, name: "BingoAce", earnings: 9200, gamesWon: 138, winRate: 69, country: "Japan" },
  { rank: 8, name: "WinnerTakesAll", earnings: 8650, gamesWon: 125, winRate: 67, country: "Brazil" },
];

export default function Leaderboard({ onBack }: LeaderboardProps) {
  const [activeTab, setActiveTab] = useState<LeaderboardTab>('global');
  const [activeFilter, setActiveFilter] = useState<LeaderboardFilter>('alltime');

  const getRankColor = (rank: number) => {
    switch (rank) {
      case 1: return 'text-yellow-400';
      case 2: return 'text-gray-300';
      case 3: return 'text-orange-400';
      default: return 'text-white';
    }
  };

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return '🥇';
      case 2: return '🥈';
      case 3: return '🥉';
      default: return rank.toString();
    }
  };

  return (
    <div className="w-full h-full bg-gradient-to-br from-gray-900 via-black to-gray-800 flex flex-col overflow-hidden">
      {/* Header */}
      <div className="flex justify-between items-center p-4 border-b border-gray-700">
        <button
          onClick={onBack}
          className="cartoon-button w-12 h-12 flex items-center justify-center text-gray-800"
        >
          <ArrowLeft size={20} />
        </button>
        
        <h1 className="fredoka text-2xl font-bold text-white">Leaderboard</h1>
        
        <div className="w-12 h-12"></div> {/* Spacer */}
      </div>

      {/* Tabs */}
      <div className="flex space-x-1 p-4 bg-gray-800 border-b border-gray-700">
        <button
          onClick={() => setActiveTab('global')}
          className={`flex-1 py-3 px-4 rounded-lg fredoka font-bold transition-all duration-200 ${
            activeTab === 'global' 
              ? 'bg-red-500 text-white' 
              : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
          }`}
        >
          <Globe size={20} className="inline mr-2" />
          Global
        </button>
        <button
          onClick={() => setActiveTab('country')}
          className={`flex-1 py-3 px-4 rounded-lg fredoka font-bold transition-all duration-200 ${
            activeTab === 'country' 
              ? 'bg-red-500 text-white' 
              : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
          }`}
        >
          <MapPin size={20} className="inline mr-2" />
          Country
        </button>
      </div>

      {/* Filters */}
      <div className="flex space-x-1 p-4 bg-gray-800 border-b border-gray-700">
        <button
          onClick={() => setActiveFilter('weekly')}
          className={`flex-1 py-2 px-4 rounded-lg fredoka font-bold transition-all duration-200 ${
            activeFilter === 'weekly' 
              ? 'bg-blue-500 text-white' 
              : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
          }`}
        >
          <Calendar size={16} className="inline mr-2" />
          Weekly
        </button>
        <button
          onClick={() => setActiveFilter('alltime')}
          className={`flex-1 py-2 px-4 rounded-lg fredoka font-bold transition-all duration-200 ${
            activeFilter === 'alltime' 
              ? 'bg-blue-500 text-white' 
              : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
          }`}
        >
          <Clock size={16} className="inline mr-2" />
          All Time
        </button>
      </div>

      {/* Leaderboard Content */}
      <div className="flex-1 overflow-y-auto p-4">
        {/* Top 3 Podium */}
        <div className="mb-6">
          <h2 className="fredoka text-xl font-bold text-white mb-4 text-center">
            Top Players
          </h2>
          <div className="flex justify-center items-end space-x-4 mb-6">
            {/* 2nd Place */}
            {mockLeaderboard[1] && (
              <div className="flex flex-col items-center">
                <div className="w-16 h-16 bg-gradient-to-br from-gray-300 to-gray-500 rounded-full 
                               flex items-center justify-center border-4 border-white text-2xl mb-2">
                  🥈
                </div>
                <div className="bg-gray-700 h-20 w-20 flex flex-col items-center justify-center rounded-t-lg">
                  <div className="text-xs text-gray-300 text-center font-bold">
                    {mockLeaderboard[1].name}
                  </div>
                  <div className="text-xs text-yellow-400">
                    ${mockLeaderboard[1].earnings}
                  </div>
                </div>
              </div>
            )}

            {/* 1st Place */}
            {mockLeaderboard[0] && (
              <div className="flex flex-col items-center">
                <div className="w-20 h-20 bg-gradient-to-br from-yellow-300 to-yellow-600 rounded-full 
                               flex items-center justify-center border-4 border-white text-3xl mb-2">
                  🥇
                </div>
                <div className="bg-yellow-600 h-28 w-24 flex flex-col items-center justify-center rounded-t-lg">
                  <div className="text-sm text-white text-center font-bold">
                    {mockLeaderboard[0].name}
                  </div>
                  <div className="text-sm text-yellow-100">
                    ${mockLeaderboard[0].earnings}
                  </div>
                </div>
              </div>
            )}

            {/* 3rd Place */}
            {mockLeaderboard[2] && (
              <div className="flex flex-col items-center">
                <div className="w-16 h-16 bg-gradient-to-br from-orange-400 to-orange-600 rounded-full 
                               flex items-center justify-center border-4 border-white text-2xl mb-2">
                  🥉
                </div>
                <div className="bg-orange-600 h-16 w-20 flex flex-col items-center justify-center rounded-t-lg">
                  <div className="text-xs text-white text-center font-bold">
                    {mockLeaderboard[2].name}
                  </div>
                  <div className="text-xs text-orange-100">
                    ${mockLeaderboard[2].earnings}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Full Leaderboard */}
        <div className="space-y-2">
          {mockLeaderboard.map((player, index) => (
            <div
              key={player.rank}
              className={`bg-gray-800 rounded-lg p-4 border-2 border-gray-600 
                         ${index < 3 ? 'ring-2 ring-yellow-400 bg-gray-700' : ''}`}
            >
              <div className="flex items-center space-x-4">
                {/* Rank */}
                <div className={`text-2xl font-bold ${getRankColor(player.rank)} w-12 text-center`}>
                  {getRankIcon(player.rank)}
                </div>

                {/* Player Info */}
                <div className="flex-1">
                  <div className="flex items-center space-x-2">
                    <span className="fredoka text-lg font-bold text-white">
                      {player.name}
                    </span>
                    <span className="text-sm text-gray-400">
                      ({player.country})
                    </span>
                  </div>
                  <div className="flex items-center space-x-4 text-sm text-gray-300">
                    <span>Won: {player.gamesWon}</span>
                    <span>Rate: {player.winRate}%</span>
                  </div>
                </div>

                {/* Earnings */}
                <div className="text-right">
                  <div className="text-xl font-bold text-yellow-400">
                    ${player.earnings.toLocaleString()}
                  </div>
                  <div className="text-sm text-gray-400">
                    earnings
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Current Player Position */}
        <div className="mt-6 p-4 bg-red-800 rounded-lg border-2 border-red-600">
          <div className="flex items-center space-x-4">
            <Trophy size={24} className="text-red-400" />
            <div className="flex-1">
              <div className="fredoka text-lg font-bold text-white">Your Position</div>
              <div className="text-sm text-red-200">
                Rank #127 - Keep playing to climb higher!
              </div>
            </div>
            <div className="text-right">
              <div className="text-lg font-bold text-yellow-400">$420</div>
              <div className="text-sm text-red-200">earnings</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
