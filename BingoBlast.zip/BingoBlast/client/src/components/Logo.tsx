import { useEffect, useState } from "react";

interface LogoProps {
  size?: 'small' | 'medium' | 'large';
  animated?: boolean;
  className?: string;
}

export default function Logo({ size = 'medium', animated = true, className = '' }: LogoProps) {
  const [isAnimating, setIsAnimating] = useState(false);
  const [rotationAngle, setRotationAngle] = useState(0);
  const [pulsePhase, setPulsePhase] = useState(0);

  useEffect(() => {
    if (animated) {
      setIsAnimating(true);
      
      // Smooth rotation animation
      const rotationInterval = setInterval(() => {
        setRotationAngle(prev => (prev + 1) % 360);
      }, 30);
      
      // Pulse animation
      const pulseInterval = setInterval(() => {
        setPulsePhase(prev => (prev + 1) % 100);
      }, 50);
      
      return () => {
        clearInterval(rotationInterval);
        clearInterval(pulseInterval);
        setIsAnimating(false);
      };
    }
  }, [animated]);

  const sizeClasses = {
    small: 'w-16 h-16',
    medium: 'w-24 h-24',
    large: 'w-32 h-32'
  };

  const textSizes = {
    small: 'text-lg',
    medium: 'text-2xl',
    large: 'text-4xl'
  };

  return (
    <div className={`${sizeClasses[size]} ${className} relative`}>
      {/* Animated SVG Background */}
      <svg 
        className="absolute inset-0 w-full h-full" 
        viewBox="0 0 100 100"
        style={{ transform: `rotate(${rotationAngle}deg)` }}
      >
        <defs>
          <radialGradient id="logoGradient" cx="50%" cy="30%" r="70%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.8" />
            <stop offset="20%" stopColor="#fbbf24" stopOpacity="0.6" />
            <stop offset="40%" stopColor="#ef4444" stopOpacity="0.8" />
            <stop offset="60%" stopColor="#ec4899" stopOpacity="0.7" />
            <stop offset="80%" stopColor="#8b5cf6" stopOpacity="0.6" />
            <stop offset="100%" stopColor="#1f2937" stopOpacity="0.9" />
          </radialGradient>
          
          <radialGradient id="bingoGradient" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#fef3c7" />
            <stop offset="30%" stopColor="#fbbf24" />
            <stop offset="60%" stopColor="#f59e0b" />
            <stop offset="100%" stopColor="#d97706" />
          </radialGradient>
          
          <filter id="glow">
            <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
            <feMerge> 
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/> 
            </feMerge>
          </filter>
          
          <pattern id="bingoPattern" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
            <circle cx="10" cy="10" r="2" fill="#ffffff" opacity="0.3">
              <animate attributeName="opacity" values="0.3;0.8;0.3" dur="2s" repeatCount="indefinite" />
            </circle>
          </pattern>
        </defs>
        
        {/* Main circle with gradient */}
        <circle 
          cx="50" 
          cy="50" 
          r="45" 
          fill="url(#logoGradient)" 
          stroke="url(#bingoGradient)" 
          strokeWidth="3"
          filter="url(#glow)"
        />
        
        {/* Inner pattern */}
        <circle cx="50" cy="50" r="40" fill="url(#bingoPattern)" />
        
        {/* Animated rings */}
        <circle 
          cx="50" 
          cy="50" 
          r="35" 
          fill="none" 
          stroke="#fbbf24" 
          strokeWidth="2" 
          opacity="0.6"
          strokeDasharray="10,5"
          transform={`rotate(${-rotationAngle * 2} 50 50)`}
        />
        
        <circle 
          cx="50" 
          cy="50" 
          r="42" 
          fill="none" 
          stroke="#ec4899" 
          strokeWidth="1" 
          opacity="0.4"
          strokeDasharray="5,3"
          transform={`rotate(${rotationAngle * 1.5} 50 50)`}
        />
      </svg>

      {/* Central BINGO text */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-center transform transition-all duration-300">
          {/* Main BINGO text */}
          <div 
            className={`fredoka font-black text-white ${size === 'large' ? 'text-xl' : size === 'medium' ? 'text-lg' : 'text-sm'}`}
            style={{ 
              textShadow: '2px 2px 4px rgba(0,0,0,0.8), 0 0 20px rgba(255,184,36,0.6)',
              transform: `scale(${1 + Math.sin(pulsePhase * 0.1) * 0.1})`,
              filter: 'drop-shadow(0 0 10px rgba(255,184,36,0.8))'
            }}
          >
            BINGO
          </div>
          
          {/* Subtitle */}
          <div 
            className={`fredoka font-semibold text-yellow-200 ${size === 'large' ? 'text-xs' : 'text-[10px]'} mt-1`}
            style={{ 
              textShadow: '1px 1px 2px rgba(0,0,0,0.8)',
              opacity: 0.9
            }}
          >
            GAME
          </div>
        </div>
      </div>

      {/* Floating elements */}
      {isAnimating && (
        <>
          {/* Bingo balls */}
          <div 
            className="absolute w-3 h-3 rounded-full bg-gradient-to-br from-yellow-300 to-orange-400 shadow-lg"
            style={{
              top: '10%',
              right: '15%',
              transform: `translateY(${Math.sin(pulsePhase * 0.05) * 5}px)`,
              boxShadow: '0 0 10px rgba(251,191,36,0.8)'
            }}
          >
            <div className="w-full h-full rounded-full bg-white opacity-40"></div>
            <div className="absolute top-1 left-1 w-1 h-1 rounded-full bg-white opacity-80"></div>
          </div>
          
          <div 
            className="absolute w-2 h-2 rounded-full bg-gradient-to-br from-blue-300 to-blue-500 shadow-lg"
            style={{
              bottom: '20%',
              left: '10%',
              transform: `translateY(${Math.sin((pulsePhase + 30) * 0.05) * 3}px)`,
              boxShadow: '0 0 8px rgba(59,130,246,0.8)'
            }}
          >
            <div className="w-full h-full rounded-full bg-white opacity-40"></div>
          </div>
          
          <div 
            className="absolute w-2 h-2 rounded-full bg-gradient-to-br from-green-300 to-green-500 shadow-lg"
            style={{
              top: '30%',
              left: '5%',
              transform: `translateY(${Math.sin((pulsePhase + 60) * 0.05) * 4}px)`,
              boxShadow: '0 0 8px rgba(34,197,94,0.8)'
            }}
          >
            <div className="w-full h-full rounded-full bg-white opacity-40"></div>
          </div>
          
          <div 
            className="absolute w-2 h-2 rounded-full bg-gradient-to-br from-purple-300 to-purple-500 shadow-lg"
            style={{
              bottom: '10%',
              right: '20%',
              transform: `translateY(${Math.sin((pulsePhase + 90) * 0.05) * 3}px)`,
              boxShadow: '0 0 8px rgba(147,51,234,0.8)'
            }}
          >
            <div className="w-full h-full rounded-full bg-white opacity-40"></div>
          </div>

          {/* Sparkles */}
          {Array.from({ length: 8 }).map((_, i) => (
            <div
              key={i}
              className="absolute w-1 h-1 bg-white rounded-full"
              style={{
                top: `${20 + Math.sin(i) * 30}%`,
                left: `${20 + Math.cos(i) * 30}%`,
                opacity: Math.abs(Math.sin((pulsePhase + i * 20) * 0.1)),
                transform: `scale(${0.5 + Math.abs(Math.sin((pulsePhase + i * 15) * 0.1)) * 0.5})`,
                boxShadow: '0 0 4px rgba(255,255,255,0.8)'
              }}
            />
          ))}
        </>
      )}

      {/* Outer glow effect */}
      {isAnimating && (
        <div 
          className="absolute inset-0 rounded-full blur-xl"
          style={{
            background: `radial-gradient(circle, rgba(251,191,36,${0.3 + Math.sin(pulsePhase * 0.1) * 0.2}) 0%, transparent 70%)`,
            transform: `scale(${1.2 + Math.sin(pulsePhase * 0.08) * 0.1})`
          }}
        />
      )}
    </div>
  );
}
