import { useState, useEffect } from "react";
import { useMultiplayer } from "../lib/stores/useMultiplayer";
import { ArrowLeft, Users, Lock, Unlock, Copy, Check } from "lucide-react";

interface MultiplayerLobbyProps {
  onBack: () => void;
  onStartGame: () => void;
}

type LobbyView = 'selection' | 'matchmaking' | 'create-room' | 'join-room' | 'room-lobby';

export default function MultiplayerLobby({ onBack, onStartGame }: MultiplayerLobbyProps) {
  const [currentView, setCurrentView] = useState<LobbyView>('selection');
  const [selectedPlayerCount, setSelectedPlayerCount] = useState(2);
  const [roomName, setRoomName] = useState('');
  const [roomPassword, setRoomPassword] = useState('');
  const [isPrivateRoom, setIsPrivateRoom] = useState(false);
  const [joinRoomCode, setJoinRoomCode] = useState('');
  const [joinRoomPassword, setJoinRoomPassword] = useState('');
  const [copiedRoomCode, setCopiedRoomCode] = useState(false);

  const {
    mode,
    currentRoom,
    availableRooms,
    isConnected,
    playerId,
    createRoom,
    joinRoom,
    leaveRoom,
    setPlayerReady,
    startMatchmaking,
    cancelMatchmaking,
    refreshRooms
  } = useMultiplayer();

  useEffect(() => {
    if (mode === 'matchmaking') {
      setCurrentView('matchmaking');
    } else if (mode === 'custom-room' && currentRoom) {
      setCurrentView('room-lobby');
    }
  }, [mode, currentRoom]);

  useEffect(() => {
    if (currentView === 'join-room') {
      refreshRooms();
    }
  }, [currentView, refreshRooms]);

  const handleCreateRoom = async () => {
    if (!roomName.trim()) return;
    
    try {
      const roomId = await createRoom(roomName, selectedPlayerCount, isPrivateRoom, roomPassword || undefined);
      console.log(`Room created with ID: ${roomId}`);
    } catch (error) {
      console.error('Failed to create room:', error);
    }
  };

  const handleJoinRoom = async (roomId?: string, password?: string) => {
    const targetRoomId = roomId || joinRoomCode;
    const targetPassword = password || joinRoomPassword;
    
    if (!targetRoomId.trim()) return;
    
    try {
      const success = await joinRoom(targetRoomId, targetPassword || undefined);
      if (!success) {
        alert('Failed to join room. Check room code and password.');
      }
    } catch (error) {
      console.error('Failed to join room:', error);
    }
  };

  const handleStartMatchmaking = () => {
    startMatchmaking(selectedPlayerCount);
  };

  const handleCopyRoomCode = () => {
    if (currentRoom) {
      navigator.clipboard.writeText(currentRoom.id);
      setCopiedRoomCode(true);
      setTimeout(() => setCopiedRoomCode(false), 2000);
    }
  };

  const handlePlayerReady = () => {
    const player = currentRoom?.players.find(p => p.id === playerId);
    setPlayerReady(!player?.isReady);
  };

  const canStartGame = currentRoom?.players.every(p => p.isReady) && 
                      currentRoom?.players.length >= 2;

  const renderPlayerSelection = () => (
    <div className="space-y-6">
      <h2 className="fredoka text-2xl font-bold text-white text-center">Choose Player Count</h2>
      
      <div className="grid grid-cols-2 gap-4">
        {[2, 4, 6, 8].map(count => (
          <button
            key={count}
            onClick={() => setSelectedPlayerCount(count)}
            className={`cartoon-button h-16 px-4 fredoka font-bold text-gray-800 relative overflow-hidden
                       ${selectedPlayerCount === count ? 'ring-4 ring-red-400' : ''}`}
          >
            <div className="flex items-center justify-center space-x-2">
              <Users size={24} />
              <span>{count} Players</span>
            </div>
          </button>
        ))}
      </div>

      <div className="space-y-4">
        <button
          onClick={handleStartMatchmaking}
          className="w-full cartoon-button-red h-14 px-6 fredoka text-lg font-bold"
        >
          Quick Match ({selectedPlayerCount} Players)
        </button>
        
        <button
          onClick={() => setCurrentView('create-room')}
          className="w-full cartoon-button h-14 px-6 fredoka text-lg font-bold text-gray-800"
        >
          Create Custom Room
        </button>
        
        <button
          onClick={() => setCurrentView('join-room')}
          className="w-full cartoon-button h-14 px-6 fredoka text-lg font-bold text-gray-800"
        >
          Join Room
        </button>
      </div>
    </div>
  );

  const renderMatchmaking = () => (
    <div className="space-y-6 text-center">
      <h2 className="fredoka text-2xl font-bold text-white">Finding Players...</h2>
      
      <div className="flex justify-center">
        <div className="w-16 h-16 border-4 border-gray-600 border-t-red-500 rounded-full animate-spin"></div>
      </div>
      
      <p className="text-gray-300">
        Looking for {selectedPlayerCount - 1} more players
      </p>
      
      <button
        onClick={() => {
          cancelMatchmaking();
          setCurrentView('selection');
        }}
        className="cartoon-button px-6 py-3 fredoka font-bold text-gray-800"
      >
        Cancel
      </button>
    </div>
  );

  const renderCreateRoom = () => (
    <div className="space-y-6">
      <h2 className="fredoka text-2xl font-bold text-white text-center">Create Room</h2>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Room Name</label>
          <input
            type="text"
            value={roomName}
            onChange={(e) => setRoomName(e.target.value)}
            className="w-full px-4 py-3 bg-gray-800 border border-gray-600 rounded-lg text-white 
                     focus:outline-none focus:ring-2 focus:ring-red-500"
            placeholder="Enter room name"
            maxLength={20}
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Max Players</label>
          <div className="grid grid-cols-4 gap-2">
            {[2, 4, 6, 8].map(count => (
              <button
                key={count}
                onClick={() => setSelectedPlayerCount(count)}
                className={`cartoon-button h-12 fredoka font-bold text-gray-800
                           ${selectedPlayerCount === count ? 'bg-red-500 text-white' : ''}`}
              >
                {count}
              </button>
            ))}
          </div>
        </div>
        
        <div className="flex items-center space-x-3">
          <button
            onClick={() => setIsPrivateRoom(!isPrivateRoom)}
            className={`cartoon-button w-12 h-12 flex items-center justify-center
                       ${isPrivateRoom ? 'bg-red-500 text-white' : 'text-gray-800'}`}
          >
            {isPrivateRoom ? <Lock size={20} /> : <Unlock size={20} />}
          </button>
          <span className="text-gray-300">Private Room</span>
        </div>
        
        {isPrivateRoom && (
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Room Password</label>
            <input
              type="password"
              value={roomPassword}
              onChange={(e) => setRoomPassword(e.target.value)}
              className="w-full px-4 py-3 bg-gray-800 border border-gray-600 rounded-lg text-white 
                       focus:outline-none focus:ring-2 focus:ring-red-500"
              placeholder="Enter password"
            />
          </div>
        )}
        
        <div className="flex space-x-2">
          <button
            onClick={handleCreateRoom}
            disabled={!roomName.trim()}
            className="flex-1 cartoon-button-red py-3 fredoka font-bold disabled:opacity-50"
          >
            Create Room
          </button>
          <button
            onClick={() => setCurrentView('selection')}
            className="flex-1 cartoon-button py-3 fredoka font-bold text-gray-800"
          >
            Back
          </button>
        </div>
      </div>
    </div>
  );

  const renderJoinRoom = () => (
    <div className="space-y-6">
      <h2 className="fredoka text-2xl font-bold text-white text-center">Join Room</h2>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Room Code</label>
          <input
            type="text"
            value={joinRoomCode}
            onChange={(e) => setJoinRoomCode(e.target.value.toUpperCase())}
            className="w-full px-4 py-3 bg-gray-800 border border-gray-600 rounded-lg text-white 
                     focus:outline-none focus:ring-2 focus:ring-red-500 fredoka text-center text-lg"
            placeholder="ENTER CODE"
            maxLength={6}
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Password (if required)</label>
          <input
            type="password"
            value={joinRoomPassword}
            onChange={(e) => setJoinRoomPassword(e.target.value)}
            className="w-full px-4 py-3 bg-gray-800 border border-gray-600 rounded-lg text-white 
                     focus:outline-none focus:ring-2 focus:ring-red-500"
            placeholder="Enter password"
          />
        </div>
        
        <div className="flex space-x-2">
          <button
            onClick={() => handleJoinRoom()}
            disabled={!joinRoomCode.trim()}
            className="flex-1 cartoon-button-red py-3 fredoka font-bold disabled:opacity-50"
          >
            Join Room
          </button>
          <button
            onClick={() => setCurrentView('selection')}
            className="flex-1 cartoon-button py-3 fredoka font-bold text-gray-800"
          >
            Back
          </button>
        </div>
      </div>
      
      {/* Available Public Rooms */}
      {availableRooms.length > 0 && (
        <div className="space-y-4">
          <h3 className="fredoka text-lg font-bold text-white">Available Rooms</h3>
          <div className="space-y-2 max-h-40 overflow-y-auto">
            {availableRooms.map(room => (
              <div key={room.id} className="bg-gray-800 rounded-lg p-3 border border-gray-600">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-semibold text-white">{room.name}</div>
                    <div className="text-sm text-gray-400">
                      {room.playerCount}/{room.maxPlayers} players
                    </div>
                  </div>
                  <button
                    onClick={() => handleJoinRoom(room.id)}
                    className="cartoon-button px-4 py-2 fredoka font-bold text-gray-800"
                  >
                    Join
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );

  const renderRoomLobby = () => {
    if (!currentRoom) return null;
    
    return (
      <div className="space-y-6">
        <div className="text-center">
          <h2 className="fredoka text-2xl font-bold text-white">{currentRoom.name}</h2>
          <div className="flex items-center justify-center space-x-2 mt-2">
            <span className="text-gray-300">Room Code:</span>
            <span className="fredoka text-xl text-red-400">{currentRoom.id}</span>
            <button
              onClick={handleCopyRoomCode}
              className="cartoon-button w-8 h-8 flex items-center justify-center text-gray-800"
            >
              {copiedRoomCode ? <Check size={16} /> : <Copy size={16} />}
            </button>
          </div>
        </div>
        
        {/* Players List */}
        <div className="space-y-3">
          <h3 className="fredoka text-lg font-bold text-white">
            Players ({currentRoom.playerCount}/{currentRoom.maxPlayers})
          </h3>
          
          <div className="space-y-2">
            {currentRoom.players.map((player, index) => (
              <div key={player.id} className="bg-gray-800 rounded-lg p-3 border border-gray-600">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold
                                   ${player.id === currentRoom.host ? 'bg-yellow-500 text-black' : 'bg-gray-600 text-white'}`}>
                      {player.name.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <div className="font-semibold text-white">
                        {player.name}
                        {player.id === currentRoom.host && (
                          <span className="ml-2 text-xs bg-yellow-500 text-black px-2 py-1 rounded-full">
                            HOST
                          </span>
                        )}
                      </div>
                      <div className={`text-sm ${player.isReady ? 'text-green-400' : 'text-gray-400'}`}>
                        {player.isReady ? 'Ready' : 'Not Ready'}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Ready/Start Controls */}
        <div className="space-y-4">
          <button
            onClick={handlePlayerReady}
            className={`w-full h-14 fredoka text-lg font-bold
                       ${currentRoom.players.find(p => p.id === playerId)?.isReady 
                         ? 'cartoon-button text-gray-800' 
                         : 'cartoon-button-red'}`}
          >
            {currentRoom.players.find(p => p.id === playerId)?.isReady ? 'Not Ready' : 'Ready'}
          </button>
          
          {currentRoom.host === playerId && canStartGame && (
            <button
              onClick={onStartGame}
              className="w-full cartoon-button-red h-16 fredoka text-xl font-bold pulse-glow"
            >
              Start Game
            </button>
          )}
          
          <button
            onClick={() => {
              leaveRoom();
              setCurrentView('selection');
            }}
            className="w-full cartoon-button h-12 fredoka font-bold text-gray-800"
          >
            Leave Room
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="w-full h-full bg-gradient-to-br from-gray-900 via-black to-gray-800 flex flex-col overflow-hidden">
      {/* Header */}
      <div className="flex justify-between items-center p-4 border-b border-gray-700">
        <button
          onClick={() => {
            if (currentView !== 'selection') {
              setCurrentView('selection');
            } else {
              onBack();
            }
          }}
          className="cartoon-button w-12 h-12 flex items-center justify-center text-gray-800"
        >
          <ArrowLeft size={20} />
        </button>
        
        <h1 className="fredoka text-2xl font-bold text-white">Multiplayer</h1>
        
        <div className="w-12 h-12"></div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4">
        <div className="max-w-md mx-auto">
          {currentView === 'selection' && renderPlayerSelection()}
          {currentView === 'matchmaking' && renderMatchmaking()}
          {currentView === 'create-room' && renderCreateRoom()}
          {currentView === 'join-room' && renderJoinRoom()}
          {currentView === 'room-lobby' && renderRoomLobby()}
        </div>
      </div>
    </div>
  );
}