import { useEffect, useState } from "react";
import Logo from "./Logo";

export default function SplashScreen() {
  const [logoVisible, setLogoVisible] = useState(false);
  const [textVisible, setTextVisible] = useState(false);

  useEffect(() => {
    // Animate logo appearance
    const logoTimer = setTimeout(() => {
      setLogoVisible(true);
    }, 500);

    // Animate text appearance
    const textTimer = setTimeout(() => {
      setTextVisible(true);
    }, 1500);

    return () => {
      clearTimeout(logoTimer);
      clearTimeout(textTimer);
    };
  }, []);

  return (
    <div className="w-full h-full bg-gradient-to-br from-gray-900 via-black to-gray-800 flex flex-col items-center justify-center relative overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-20 h-20 bg-red-500 rounded-full blur-xl"></div>
        <div className="absolute top-1/3 right-10 w-16 h-16 bg-white rounded-full blur-lg"></div>
        <div className="absolute bottom-1/4 left-1/4 w-24 h-24 bg-gray-400 rounded-full blur-2xl"></div>
        <div className="absolute bottom-10 right-1/3 w-18 h-18 bg-red-400 rounded-full blur-xl"></div>
      </div>

      {/* Logo */}
      <div className={`transform transition-all duration-1000 ${logoVisible ? 'scale-100 opacity-100' : 'scale-50 opacity-0'}`}>
        <Logo size="large" animated={logoVisible} />
      </div>

      {/* Title */}
      <div className={`mt-8 text-center transform transition-all duration-1000 delay-500 ${textVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
        <h1 className="fredoka text-6xl sm:text-8xl font-bold text-white mb-2 tracking-wider">
          BINGO
        </h1>
        <p className="text-lg sm:text-xl text-gray-300 font-semibold">
          made by TiRRuS
        </p>
      </div>

      {/* Loading indicator */}
      <div className={`mt-12 transform transition-all duration-1000 delay-1000 ${textVisible ? 'opacity-100' : 'opacity-0'}`}>
        <div className="w-8 h-8 border-4 border-gray-600 border-t-red-500 rounded-full animate-spin"></div>
      </div>
    </div>
  );
}
