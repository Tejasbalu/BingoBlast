import { useState, useEffect } from "react";

interface AIBotProps {
  isWinner?: boolean;
  isPlaying?: boolean;
  currentNumber?: number | null;
}

const botReactions = {
  idle: ['😐', '🤔', '😊', '🎯'],
  thinking: ['🤔', '💭', '🎲', '🎯'],
  excited: ['😄', '🎉', '😁', '🥳'],
  disappointed: ['😔', '😞', '😕', '😐'],
  winner: ['🎉', '🥳', '🏆', '😎'],
  concentrating: ['🧐', '🤨', '😤', '💪']
};

const botMessages = {
  idle: ["Ready to play!", "Let's do this!", "Good luck!", "May the best player win!"],
  thinking: ["Hmm...", "Let me think...", "Interesting...", "Calculating..."],
  excited: ["Great number!", "Yes!", "This is good!", "Perfect!"],
  disappointed: ["Oh no!", "Missed it!", "Darn!", "Next time!"],
  winner: ["BINGO! I won!", "Victory is mine!", "Great game!", "GG!"],
  concentrating: ["Focus time!", "Getting close!", "Almost there!", "So close!"]
};

export default function AIBot({ isWinner, isPlaying, currentNumber }: AIBotProps) {
  const [currentEmotion, setCurrentEmotion] = useState<keyof typeof botReactions>('idle');
  const [currentMessage, setCurrentMessage] = useState('');
  const [isAnimating, setIsAnimating] = useState(false);

  // Update bot emotion based on game state
  useEffect(() => {
    if (isWinner) {
      setCurrentEmotion('winner');
      setCurrentMessage(botMessages.winner[Math.floor(Math.random() * botMessages.winner.length)]);
      setIsAnimating(true);
    } else if (isPlaying) {
      if (currentNumber) {
        // Randomly react to numbers
        const reactions = ['thinking', 'excited', 'disappointed', 'concentrating'];
        const randomReaction = reactions[Math.floor(Math.random() * reactions.length)] as keyof typeof botReactions;
        setCurrentEmotion(randomReaction);
        setCurrentMessage(botMessages[randomReaction][Math.floor(Math.random() * botMessages[randomReaction].length)]);
        setIsAnimating(true);
      } else {
        setCurrentEmotion('concentrating');
        setCurrentMessage(botMessages.concentrating[Math.floor(Math.random() * botMessages.concentrating.length)]);
      }
    } else {
      setCurrentEmotion('idle');
      setCurrentMessage(botMessages.idle[Math.floor(Math.random() * botMessages.idle.length)]);
    }
  }, [isWinner, isPlaying, currentNumber]);

  // Reset animation
  useEffect(() => {
    if (isAnimating) {
      const timer = setTimeout(() => setIsAnimating(false), 1000);
      return () => clearTimeout(timer);
    }
  }, [isAnimating]);

  const getRandomEmoji = () => {
    const emojis = botReactions[currentEmotion];
    return emojis[Math.floor(Math.random() * emojis.length)];
  };

  return (
    <div className="flex flex-col items-center space-y-4 p-6">
      {/* AI Bot Avatar */}
      <div className={`relative w-32 h-32 rounded-full bg-gradient-to-br from-blue-400 via-purple-500 to-pink-500 
                      flex items-center justify-center border-4 border-white shadow-2xl
                      ${isAnimating ? 'animate-bounce' : ''}
                      ${isWinner ? 'pulse-glow' : ''}`}>
        
        {/* Bot Face */}
        <div className="text-6xl animate-pulse">
          {getRandomEmoji()}
        </div>
        
        {/* Winner Crown */}
        {isWinner && (
          <div className="absolute -top-6 text-3xl animate-bounce">
            👑
          </div>
        )}
        
        {/* Glossy effect */}
        <div className="absolute inset-0 bg-gradient-to-br from-white/30 via-transparent to-transparent rounded-full"></div>
      </div>

      {/* AI Name */}
      <div className="text-center">
        <h3 className="fredoka text-2xl font-bold text-white mb-1">
          AI Bot
        </h3>
        <div className="text-sm text-gray-400">
          Level: Expert
        </div>
      </div>

      {/* Bot Message */}
      <div className={`bg-gray-800 px-4 py-2 rounded-xl border-2 border-gray-600 min-w-[150px] text-center
                      ${isAnimating ? 'shake' : ''}`}>
        <p className="text-white font-semibold">
          {currentMessage}
        </p>
      </div>

      {/* Bot Status Indicator */}
      <div className="flex items-center space-x-2">
        <div className={`w-3 h-3 rounded-full ${isPlaying ? 'bg-green-400 animate-pulse' : 'bg-gray-400'}`}></div>
        <span className="text-sm text-gray-400">
          {isPlaying ? 'Active' : 'Waiting'}
        </span>
      </div>

      {/* Bot Stats */}
      <div className="bg-gray-800 px-4 py-2 rounded-lg border border-gray-600">
        <div className="text-xs text-gray-400 text-center">
          <div>Games Won: 127</div>
          <div>Win Rate: 62%</div>
        </div>
      </div>
    </div>
  );
}
