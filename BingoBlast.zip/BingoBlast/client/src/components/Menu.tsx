import { useState } from "react";
import { ArrowLeft, Settings, ShoppingBag, Gift, Volume2, VolumeX, Smartphone } from "lucide-react";
import { useAudio } from "../lib/stores/useAudio";

interface MenuProps {
  onBack: () => void;
}

export default function Menu({ onBack }: MenuProps) {
  const { isMuted, toggleMute } = useAudio();
  const [inviteCode, setInviteCode] = useState('');
  const [showInviteInput, setShowInviteInput] = useState(false);

  const handleEnterInviteCode = () => {
    if (inviteCode.trim()) {
      alert(`Invite code "${inviteCode}" entered! (Feature coming soon)`);
      setInviteCode('');
      setShowInviteInput(false);
    }
  };

  const menuItems = [
    {
      id: 'settings',
      title: 'In-Game Settings',
      description: 'Adjust game preferences',
      icon: Settings,
      action: () => alert('Settings panel coming soon!')
    },
    {
      id: 'shop',
      title: 'Shop',
      description: 'Buy custom Bingo boards',
      icon: ShoppingBag,
      action: () => alert('Shop coming soon!')
    },
    {
      id: 'invite',
      title: 'Enter Invitation Code',
      description: 'Use a friend\'s invite code',
      icon: Gift,
      action: () => setShowInviteInput(true)
    }
  ];

  return (
    <div className="w-full h-full bg-gradient-to-br from-gray-900 via-black to-gray-800 flex flex-col overflow-hidden">
      {/* Header */}
      <div className="flex justify-between items-center p-4 border-b border-gray-700">
        <button
          onClick={onBack}
          className="cartoon-button w-12 h-12 flex items-center justify-center text-gray-800"
        >
          <ArrowLeft size={20} />
        </button>
        
        <h1 className="fredoka text-2xl font-bold text-white">Menu</h1>
        
        <div className="w-12 h-12"></div> {/* Spacer */}
      </div>

      {/* Menu Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Quick Settings */}
        <div className="bg-gray-800 rounded-xl p-4 border-2 border-gray-600">
          <h2 className="fredoka text-lg font-bold text-white mb-4">Quick Settings</h2>
          
          {/* Sound Toggle */}
          <div className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
            <div className="flex items-center space-x-3">
              {isMuted ? <VolumeX size={24} className="text-red-400" /> : <Volume2 size={24} className="text-green-400" />}
              <div>
                <div className="text-white font-semibold">Sound Effects</div>
                <div className="text-sm text-gray-400">
                  {isMuted ? 'Muted' : 'Enabled'}
                </div>
              </div>
            </div>
            <button
              onClick={toggleMute}
              className={`cartoon-button px-4 py-2 fredoka font-bold text-gray-800 ${
                isMuted ? 'bg-red-400' : 'bg-green-400'
              }`}
            >
              {isMuted ? 'Unmute' : 'Mute'}
            </button>
          </div>
        </div>

        {/* Main Menu Items */}
        <div className="space-y-3">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={item.action}
              className="w-full bg-gray-800 rounded-xl p-4 border-2 border-gray-600 
                       hover:border-red-500 transition-all duration-200 text-left"
            >
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center">
                  <item.icon size={24} className="text-white" />
                </div>
                <div className="flex-1">
                  <div className="fredoka text-lg font-bold text-white">
                    {item.title}
                  </div>
                  <div className="text-sm text-gray-400">
                    {item.description}
                  </div>
                </div>
                <div className="text-gray-400">
                  →
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Invite Code Input */}
        {showInviteInput && (
          <div className="bg-gray-800 rounded-xl p-4 border-2 border-red-500">
            <h3 className="fredoka text-lg font-bold text-white mb-4">Enter Invitation Code</h3>
            <div className="space-y-4">
              <input
                type="text"
                value={inviteCode}
                onChange={(e) => setInviteCode(e.target.value.toUpperCase())}
                className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white 
                         focus:outline-none focus:ring-2 focus:ring-red-500 fredoka text-lg text-center"
                placeholder="ENTER CODE"
                maxLength={8}
              />
              <div className="flex space-x-2">
                <button
                  onClick={handleEnterInviteCode}
                  className="flex-1 cartoon-button-red py-3 px-4 fredoka font-bold"
                  disabled={!inviteCode.trim()}
                >
                  Submit
                </button>
                <button
                  onClick={() => {
                    setShowInviteInput(false);
                    setInviteCode('');
                  }}
                  className="flex-1 cartoon-button py-3 px-4 fredoka font-bold text-gray-800"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {/* App Info */}
        <div className="bg-gray-800 rounded-xl p-4 border-2 border-gray-600">
          <h3 className="fredoka text-lg font-bold text-white mb-4">About</h3>
          <div className="space-y-2 text-sm text-gray-300">
            <div className="flex justify-between">
              <span>Version:</span>
              <span>1.0.0</span>
            </div>
            <div className="flex justify-between">
              <span>Developer:</span>
              <span>TiRRuS</span>
            </div>
            <div className="flex justify-between">
              <span>Platform:</span>
              <span>Web</span>
            </div>
          </div>
        </div>

        {/* Share App */}
        <div className="bg-gray-800 rounded-xl p-4 border-2 border-gray-600">
          <h3 className="fredoka text-lg font-bold text-white mb-4">Share Bingo</h3>
          <div className="text-sm text-gray-300 mb-4">
            Invite friends to play and earn rewards!
          </div>
          <button
            onClick={() => {
              if (navigator.share) {
                navigator.share({
                  title: 'Bingo Game by TiRRuS',
                  text: 'Join me in this awesome Bingo game!',
                  url: window.location.href
                });
              } else {
                alert('Sharing feature coming soon!');
              }
            }}
            className="w-full cartoon-button py-3 px-4 fredoka font-bold text-gray-800 
                     flex items-center justify-center space-x-2"
          >
            <Smartphone size={20} />
            <span>Share Game</span>
          </button>
        </div>
      </div>
    </div>
  );
}
