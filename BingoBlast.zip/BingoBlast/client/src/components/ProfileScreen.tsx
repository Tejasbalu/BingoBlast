import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Badge } from "./ui/badge";
import { useState } from "react";

interface ProfileScreenProps {
  onBack: () => void;
}

export default function ProfileScreen({ onBack }: ProfileScreenProps) {
  const [playerName, setPlayerName] = useState("Player");
  const [playerAge, setPlayerAge] = useState("");
  
  // Mock player stats
  const playerStats = {
    matchesPlayed: 25,
    matchesWon: 12,
    winRatio: 48,
    coins: 150,
    level: 3
  };

  return (
    <div className="w-full h-full bg-black overflow-auto">
      {/* Header */}
      <div className="flex items-center p-4 bg-gray-900">
        <Button
          onClick={onBack}
          className="bg-gray-700 hover:bg-gray-600 text-white rounded-lg px-4 py-2 mr-4"
        >
          ← Back
        </Button>
        <h1 className="text-2xl font-bold text-white">Profile</h1>
      </div>

      <div className="p-4 space-y-6">
        {/* Profile Picture and Basic Info */}
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Player Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center space-x-4">
              <div className="w-20 h-20 bg-red-600 rounded-full flex items-center justify-center text-3xl font-bold text-white">
                {playerName.charAt(0).toUpperCase()}
              </div>
              <div className="flex-1 space-y-2">
                <Badge variant="secondary" className="bg-red-600 text-white">
                  Level {playerStats.level}
                </Badge>
                <div className="text-2xl font-bold text-white">💰 {playerStats.coins} Coins</div>
              </div>
            </div>
            
            <div className="space-y-4">
              <div>
                <Label htmlFor="name" className="text-gray-300">Player Name</Label>
                <Input
                  id="name"
                  value={playerName}
                  onChange={(e) => setPlayerName(e.target.value)}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
              
              <div>
                <Label htmlFor="age" className="text-gray-300">Age</Label>
                <Input
                  id="age"
                  value={playerAge}
                  onChange={(e) => setPlayerAge(e.target.value)}
                  placeholder="Enter your age"
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Player Stats */}
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Player Stats</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 bg-gray-700 rounded-lg">
                <div className="text-3xl font-bold text-white">{playerStats.matchesPlayed}</div>
                <div className="text-gray-300">Matches Played</div>
              </div>
              
              <div className="text-center p-4 bg-gray-700 rounded-lg">
                <div className="text-3xl font-bold text-green-400">{playerStats.matchesWon}</div>
                <div className="text-gray-300">Matches Won</div>
              </div>
              
              <div className="col-span-2 text-center p-4 bg-gray-700 rounded-lg">
                <div className="text-3xl font-bold text-blue-400">{playerStats.winRatio}%</div>
                <div className="text-gray-300">Win Ratio</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Login Section */}
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Account & Rewards</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button className="w-full bg-green-600 hover:bg-green-700 text-white">
              🎁 Login Daily & Earn 10 Coins
            </Button>
            
            <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">
              📱 Connect Social Account
            </Button>
            
            <Button className="w-full bg-purple-600 hover:bg-purple-700 text-white">
              ⭐ Rate App & Earn Bonus
            </Button>
          </CardContent>
        </Card>

        {/* Achievements */}
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Achievements</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center space-x-2 p-3 bg-gray-700 rounded-lg">
                <div className="text-2xl">🎯</div>
                <div>
                  <div className="text-white font-semibold">First Win</div>
                  <div className="text-gray-400 text-sm">Win your first game</div>
                </div>
              </div>
              
              <div className="flex items-center space-x-2 p-3 bg-gray-700 rounded-lg opacity-50">
                <div className="text-2xl">🔥</div>
                <div>
                  <div className="text-white font-semibold">Win Streak</div>
                  <div className="text-gray-400 text-sm">Win 5 games in a row</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
