import { useState, useEffect } from "react";
import { useBingo } from "./lib/stores/useBingo";
import { useAudio } from "./lib/stores/useAudio";
import SplashScreen from "./components/SplashScreen";
import HomePage from "./components/HomePage";
import GameBoard from "./components/GameBoard";
import Profile from "./components/Profile";
import Leaderboard from "./components/Leaderboard";
import Menu from "./components/Menu";
import MultiplayerLobby from "./components/MultiplayerLobby";
import ReferralSystem from "./components/ReferralSystem";
import "@fontsource/inter";

type GameView = 'splash' | 'home' | 'game' | 'profile' | 'leaderboard' | 'menu' | 'multiplayer' | 'referral';

function App() {
  const [currentView, setCurrentView] = useState<GameView>('splash');
  const [isLoading, setIsLoading] = useState(true);
  const { gamePhase, resetGame } = useBingo();
  const { setHitSound, setSuccessSound } = useAudio();

  // Initialize audio
  useEffect(() => {
    const initAudio = async () => {
      try {
        // Load hit sound
        const hitAudio = new Audio('/sounds/hit.mp3');
        hitAudio.preload = 'auto';
        hitAudio.volume = 0.3;
        setHitSound(hitAudio);

        // Load success sound
        const successAudio = new Audio('/sounds/success.mp3');
        successAudio.preload = 'auto';
        successAudio.volume = 0.5;
        setSuccessSound(successAudio);
      } catch (error) {
        console.log('Audio initialization failed:', error);
      }
    };

    initAudio();
  }, [setHitSound, setSuccessSound]);

  // Show splash screen for 3 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
      setCurrentView('home');
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  const handleNavigation = (view: GameView) => {
    setCurrentView(view);
    
    // Reset game when navigating away from game
    if (view !== 'game' && gamePhase !== 'waiting') {
      resetGame();
    }
  };

  const handleStartGame = () => {
    setCurrentView('game');
  };

  const handleBackToHome = () => {
    setCurrentView('home');
    resetGame();
  };

  if (isLoading || currentView === 'splash') {
    return <SplashScreen />;
  }

  return (
    <div className="w-full h-full bg-black text-white overflow-hidden">
      {currentView === 'home' && (
        <HomePage 
          onNavigate={handleNavigation}
          onStartGame={handleStartGame}
        />
      )}
      
      {currentView === 'game' && (
        <GameBoard onBackToHome={handleBackToHome} />
      )}
      
      {currentView === 'profile' && (
        <Profile onBack={() => handleNavigation('home')} />
      )}
      
      {currentView === 'leaderboard' && (
        <Leaderboard onBack={() => handleNavigation('home')} />
      )}
      
      {currentView === 'menu' && (
        <Menu onBack={() => handleNavigation('home')} />
      )}
      
      {currentView === 'multiplayer' && (
        <MultiplayerLobby 
          onBack={() => handleNavigation('home')}
          onStartGame={handleStartGame}
        />
      )}
      
      {currentView === 'referral' && (
        <ReferralSystem onBack={() => handleNavigation('home')} />
      )}
    </div>
  );
}

export default App;
