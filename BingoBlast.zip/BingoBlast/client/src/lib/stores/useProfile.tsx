import { create } from "zustand";
import { persist } from "zustand/middleware";

interface Profile {
  name: string;
  age: number;
  matchesPlayed: number;
  matchesWon: number;
  coins: number;
  inviteCode: string;
  achievements: string[];
}

interface ProfileState {
  profile: Profile;
  updateProfile: (updates: Partial<Profile>) => void;
  addCoins: (amount: number) => void;
  unlockAchievement: (achievement: string) => void;
}

const defaultProfile: Profile = {
  name: "Player",
  age: 25,
  matchesPlayed: 0,
  matchesWon: 0,
  coins: 0,
  inviteCode: generateInviteCode(),
  achievements: []
};

function generateInviteCode(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < 6; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

export const useProfile = create<ProfileState>()(
  persist(
    (set, get) => ({
      profile: defaultProfile,
      
      updateProfile: (updates) => {
        set((state) => ({
          profile: { ...state.profile, ...updates }
        }));
      },
      
      addCoins: (amount) => {
        set((state) => ({
          profile: {
            ...state.profile,
            coins: state.profile.coins + amount
          }
        }));
      },
      
      unlockAchievement: (achievement) => {
        const { profile } = get();
        if (!profile.achievements.includes(achievement)) {
          set((state) => ({
            profile: {
              ...state.profile,
              achievements: [...state.profile.achievements, achievement]
            }
          }));
        }
      }
    }),
    {
      name: 'bingo-profile',
      version: 1
    }
  )
);

// Achievement unlocking is handled in the game logic when stats are updated
