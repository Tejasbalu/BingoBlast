import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";

export type MultiplayerMode = 'none' | 'matchmaking' | 'custom-room';
export type RoomStatus = 'waiting' | 'ready' | 'playing' | 'finished';

interface Player {
  id: string;
  name: string;
  board: number[][];
  markedNumbers: Set<number>;
  isReady: boolean;
  isWinner: boolean;
}

interface Room {
  id: string;
  name: string;
  playerCount: number;
  maxPlayers: number;
  status: RoomStatus;
  players: Player[];
  host: string;
  isPrivate: boolean;
  password?: string;
}

interface MultiplayerState {
  mode: MultiplayerMode;
  currentRoom: Room | null;
  availableRooms: Room[];
  isConnected: boolean;
  playerId: string;
  playerName: string;
  
  // Room actions
  createRoom: (name: string, maxPlayers: number, isPrivate?: boolean, password?: string) => Promise<string>;
  joinRoom: (roomId: string, password?: string) => Promise<boolean>;
  leaveRoom: () => void;
  setPlayerReady: (ready: boolean) => void;
  
  // Matchmaking
  startMatchmaking: (playerCount: number) => void;
  cancelMatchmaking: () => void;
  
  // Game actions
  updatePlayerBoard: (board: number[][]) => void;
  markPlayerNumber: (number: number) => void;
  
  // Connection
  connect: () => void;
  disconnect: () => void;
  
  // Room management
  refreshRooms: () => void;
}

// Generate unique player ID
const generatePlayerId = () => {
  return 'player_' + Math.random().toString(36).substr(2, 9);
};

// Generate room code
const generateRoomCode = () => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < 6; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
};

// Mock multiplayer backend (in real app, this would be WebSocket/Socket.io)
class MockMultiplayerBackend {
  private rooms: Map<string, Room> = new Map();
  private players: Map<string, Player> = new Map();
  private matchmakingQueue: Array<{ playerId: string, playerCount: number }> = [];
  
  createRoom(hostId: string, name: string, maxPlayers: number, isPrivate: boolean = false, password?: string): string {
    const roomId = generateRoomCode();
    const room: Room = {
      id: roomId,
      name,
      playerCount: 1,
      maxPlayers,
      status: 'waiting',
      players: [],
      host: hostId,
      isPrivate,
      password
    };
    
    this.rooms.set(roomId, room);
    this.joinRoom(roomId, hostId);
    return roomId;
  }
  
  joinRoom(roomId: string, playerId: string, password?: string): boolean {
    const room = this.rooms.get(roomId);
    if (!room) return false;
    
    if (room.isPrivate && room.password !== password) return false;
    if (room.playerCount >= room.maxPlayers) return false;
    
    const player = this.players.get(playerId);
    if (!player) return false;
    
    room.players.push(player);
    room.playerCount++;
    
    return true;
  }
  
  leaveRoom(roomId: string, playerId: string): void {
    const room = this.rooms.get(roomId);
    if (!room) return;
    
    room.players = room.players.filter(p => p.id !== playerId);
    room.playerCount--;
    
    if (room.playerCount === 0) {
      this.rooms.delete(roomId);
    } else if (room.host === playerId) {
      // Transfer host to another player
      room.host = room.players[0].id;
    }
  }
  
  getRooms(): Room[] {
    return Array.from(this.rooms.values()).filter(room => !room.isPrivate);
  }
  
  getRoom(roomId: string): Room | null {
    return this.rooms.get(roomId) || null;
  }
  
  addPlayer(player: Player): void {
    this.players.set(player.id, player);
  }
  
  removePlayer(playerId: string): void {
    this.players.delete(playerId);
  }
  
  startMatchmaking(playerId: string, playerCount: number): void {
    this.matchmakingQueue.push({ playerId, playerCount });
    this.processMatchmaking();
  }
  
  cancelMatchmaking(playerId: string): void {
    this.matchmakingQueue = this.matchmakingQueue.filter(entry => entry.playerId !== playerId);
  }
  
  private processMatchmaking(): void {
    // Group players by desired player count
    const groups = new Map<number, string[]>();
    
    this.matchmakingQueue.forEach(entry => {
      if (!groups.has(entry.playerCount)) {
        groups.set(entry.playerCount, []);
      }
      groups.get(entry.playerCount)!.push(entry.playerId);
    });
    
    // Create rooms for complete groups
    groups.forEach((playerIds, playerCount) => {
      if (playerIds.length >= playerCount) {
        const hostId = playerIds[0];
        const roomId = this.createRoom(hostId, `Matchmaking Room`, playerCount);
        
        // Add other players to room
        for (let i = 1; i < playerCount; i++) {
          this.joinRoom(roomId, playerIds[i]);
        }
        
        // Remove matched players from queue
        this.matchmakingQueue = this.matchmakingQueue.filter(
          entry => !playerIds.slice(0, playerCount).includes(entry.playerId)
        );
      }
    });
  }
}

const mockBackend = new MockMultiplayerBackend();

export const useMultiplayer = create<MultiplayerState>()(
  subscribeWithSelector((set, get) => ({
    mode: 'none',
    currentRoom: null,
    availableRooms: [],
    isConnected: false,
    playerId: generatePlayerId(),
    playerName: 'Player',
    
    createRoom: async (name: string, maxPlayers: number, isPrivate = false, password?: string) => {
      const { playerId, playerName } = get();
      
      // Create player
      const player: Player = {
        id: playerId,
        name: playerName,
        board: [],
        markedNumbers: new Set(),
        isReady: false,
        isWinner: false
      };
      
      mockBackend.addPlayer(player);
      const roomId = mockBackend.createRoom(playerId, name, maxPlayers, isPrivate, password);
      const room = mockBackend.getRoom(roomId);
      
      set({
        mode: 'custom-room',
        currentRoom: room,
        isConnected: true
      });
      
      return roomId;
    },
    
    joinRoom: async (roomId: string, password?: string) => {
      const { playerId, playerName } = get();
      
      // Create player
      const player: Player = {
        id: playerId,
        name: playerName,
        board: [],
        markedNumbers: new Set(),
        isReady: false,
        isWinner: false
      };
      
      mockBackend.addPlayer(player);
      const success = mockBackend.joinRoom(roomId, playerId, password);
      
      if (success) {
        const room = mockBackend.getRoom(roomId);
        if (room) {
          set({
            mode: 'custom-room',
            currentRoom: room,
            isConnected: true
          });
        }
      }
      
      return success;
    },
    
    leaveRoom: () => {
      const { currentRoom, playerId } = get();
      if (currentRoom) {
        mockBackend.leaveRoom(currentRoom.id, playerId);
        mockBackend.removePlayer(playerId);
      }
      
      set({
        mode: 'none',
        currentRoom: null,
        isConnected: false
      });
    },
    
    setPlayerReady: (ready: boolean) => {
      const { currentRoom, playerId } = get();
      if (currentRoom) {
        const player = currentRoom.players.find(p => p.id === playerId);
        if (player) {
          player.isReady = ready;
          set({ currentRoom: { ...currentRoom } });
        }
      }
    },
    
    startMatchmaking: (playerCount: number) => {
      const { playerId, playerName } = get();
      
      // Create player
      const player: Player = {
        id: playerId,
        name: playerName,
        board: [],
        markedNumbers: new Set(),
        isReady: false,
        isWinner: false
      };
      
      mockBackend.addPlayer(player);
      mockBackend.startMatchmaking(playerId, playerCount);
      
      set({
        mode: 'matchmaking',
        isConnected: true
      });
      
      // Poll for room assignment
      const checkRoom = () => {
        const rooms = mockBackend.getRooms();
        const myRoom = rooms.find(room => 
          room.players.some(p => p.id === playerId)
        );
        
        if (myRoom) {
          set({
            mode: 'custom-room',
            currentRoom: myRoom
          });
        } else {
          setTimeout(checkRoom, 1000);
        }
      };
      
      setTimeout(checkRoom, 1000);
    },
    
    cancelMatchmaking: () => {
      const { playerId } = get();
      mockBackend.cancelMatchmaking(playerId);
      mockBackend.removePlayer(playerId);
      
      set({
        mode: 'none',
        isConnected: false
      });
    },
    
    updatePlayerBoard: (board: number[][]) => {
      const { currentRoom, playerId } = get();
      if (currentRoom) {
        const player = currentRoom.players.find(p => p.id === playerId);
        if (player) {
          player.board = board;
          set({ currentRoom: { ...currentRoom } });
        }
      }
    },
    
    markPlayerNumber: (number: number) => {
      const { currentRoom, playerId } = get();
      if (currentRoom) {
        const player = currentRoom.players.find(p => p.id === playerId);
        if (player) {
          player.markedNumbers.add(number);
          set({ currentRoom: { ...currentRoom } });
        }
      }
    },
    
    connect: () => {
      set({ isConnected: true });
    },
    
    disconnect: () => {
      const { currentRoom, playerId } = get();
      if (currentRoom) {
        mockBackend.leaveRoom(currentRoom.id, playerId);
      }
      mockBackend.removePlayer(playerId);
      
      set({
        mode: 'none',
        currentRoom: null,
        isConnected: false
      });
    },
    
    refreshRooms: () => {
      const rooms = mockBackend.getRooms();
      set({ availableRooms: rooms });
    }
  }))
);