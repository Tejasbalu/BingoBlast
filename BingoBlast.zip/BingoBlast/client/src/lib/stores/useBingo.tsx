import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";
import { generateBingoBoard, checkWinningPattern, type WinningPattern } from "../bingoLogic";

export type GamePhase = "waiting" | "playing" | "finished";

interface GameResult {
  winner: 'player' | 'ai' | 'tie';
  pattern: WinningPattern;
  winningNumbers: number[];
}

interface BingoState {
  gamePhase: GamePhase;
  playerBoard: number[][];
  aiBoard: number[][];
  calledNumbers: number[];
  currentNumber: number | null;
  gameResult: GameResult | null;
  
  // Player and AI marked numbers
  playerMarked: Set<number>;
  aiMarked: Set<number>;
  
  // Actions
  startGame: () => void;
  resetGame: () => void;
  nextNumber: () => void;
  markNumber: (number: number, player: 'player' | 'ai') => void;
  
  // AI actions
  aiPlayTurn: () => void;
}

export const useBingo = create<BingoState>()(
  subscribeWithSelector((set, get) => ({
    gamePhase: "waiting",
    playerBoard: [],
    aiBoard: [],
    calledNumbers: [],
    currentNumber: null,
    gameResult: null,
    playerMarked: new Set(),
    aiMarked: new Set(),
    
    startGame: () => {
      const playerBoard = generateBingoBoard();
      const aiBoard = generateBingoBoard();
      
      set({
        gamePhase: "playing",
        playerBoard,
        aiBoard,
        calledNumbers: [],
        currentNumber: null,
        gameResult: null,
        playerMarked: new Set(),
        aiMarked: new Set()
      });
    },
    
    resetGame: () => {
      set({
        gamePhase: "waiting",
        playerBoard: [],
        aiBoard: [],
        calledNumbers: [],
        currentNumber: null,
        gameResult: null,
        playerMarked: new Set(),
        aiMarked: new Set()
      });
    },
    
    nextNumber: () => {
      const { calledNumbers, gamePhase } = get();
      
      if (gamePhase !== "playing") return;
      
      // Generate next number (1-25)
      const availableNumbers = Array.from({ length: 25 }, (_, i) => i + 1)
        .filter(num => !calledNumbers.includes(num));
      
      if (availableNumbers.length === 0) {
        // Game over - no more numbers
        set({ gamePhase: "finished", gameResult: { winner: 'tie', pattern: 'none', winningNumbers: [] } });
        return;
      }
      
      const nextNumber = availableNumbers[Math.floor(Math.random() * availableNumbers.length)];
      
      set({
        calledNumbers: [...calledNumbers, nextNumber],
        currentNumber: nextNumber
      });
      
      // AI automatically marks its numbers
      setTimeout(() => {
        get().aiPlayTurn();
      }, 1000);
    },
    
    markNumber: (number: number, player: 'player' | 'ai') => {
      const { playerMarked, aiMarked, playerBoard, aiBoard, calledNumbers } = get();
      
      if (!calledNumbers.includes(number)) return;
      
      const newPlayerMarked = new Set(playerMarked);
      const newAiMarked = new Set(aiMarked);
      
      if (player === 'player') {
        newPlayerMarked.add(number);
      } else {
        newAiMarked.add(number);
      }
      
      set({
        playerMarked: newPlayerMarked,
        aiMarked: newAiMarked
      });
      
      // Check for wins
      const playerWin = checkWinningPattern(playerBoard, newPlayerMarked);
      const aiWin = checkWinningPattern(aiBoard, newAiMarked);
      
      if (playerWin || aiWin) {
        let winner: 'player' | 'ai' | 'tie';
        let pattern: WinningPattern;
        let winningNumbers: number[];
        
        if (playerWin && aiWin) {
          winner = 'tie';
          pattern = playerWin.pattern;
          winningNumbers = playerWin.numbers;
        } else if (playerWin) {
          winner = 'player';
          pattern = playerWin.pattern;
          winningNumbers = playerWin.numbers;
        } else {
          winner = 'ai';
          pattern = aiWin!.pattern;
          winningNumbers = aiWin!.numbers;
        }
        
        set({
          gamePhase: "finished",
          gameResult: { winner, pattern, winningNumbers }
        });
        
        // Play BINGO sound
        const bingoAudio = new Audio('/sounds/bingo-win.mp3');
        bingoAudio.volume = 0.7;
        bingoAudio.play().catch(() => {});
      }
    },
    
    aiPlayTurn: () => {
      const { aiBoard, calledNumbers, currentNumber } = get();
      
      if (!currentNumber) return;
      
      // Check if AI has this number on its board
      const hasNumber = aiBoard.some(row => row.includes(currentNumber));
      
      if (hasNumber) {
        // AI marks the number with some delay for realism
        setTimeout(() => {
          get().markNumber(currentNumber, 'ai');
        }, 500 + Math.random() * 1000);
      }
    }
  }))
);

// Subscribe to game phase changes to update profile stats
useBingo.subscribe(
  (state) => state.gameResult,
  (gameResult) => {
    if (gameResult) {
      // Update profile stats when game ends
      try {
        // Get the profile store and update stats
        import('./useProfile').then(({ useProfile }) => {
          const { updateProfile } = useProfile.getState();
          const { profile } = useProfile.getState();
          
          updateProfile({
            matchesPlayed: profile.matchesPlayed + 1,
            matchesWon: profile.matchesWon + (gameResult.winner === 'player' ? 1 : 0)
          });
        });
      } catch (error) {
        console.error('Failed to update profile:', error);
      }
    }
  }
);
