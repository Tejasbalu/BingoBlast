export type WinningPattern = 'horizontal' | 'vertical' | 'diagonal' | 'full-house' | 'none';

interface WinResult {
  pattern: WinningPattern;
  numbers: number[];
}

/**
 * Generates a random 5x5 Bingo board with numbers 1-25
 */
export function generateBingoBoard(): number[][] {
  // Create array of numbers 1-25
  const numbers = Array.from({ length: 25 }, (_, i) => i + 1);
  
  // Shuffle the numbers
  for (let i = numbers.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [numbers[i], numbers[j]] = [numbers[j], numbers[i]];
  }
  
  // Create 5x5 board
  const board: number[][] = [];
  for (let row = 0; row < 5; row++) {
    board[row] = [];
    for (let col = 0; col < 5; col++) {
      board[row][col] = numbers[row * 5 + col];
    }
  }
  
  return board;
}

/**
 * Checks if a board has a winning pattern with the given marked numbers
 */
export function checkWinningPattern(board: number[][], markedNumbers: Set<number>): WinResult | null {
  // Check horizontal lines
  for (let row = 0; row < 5; row++) {
    const rowNumbers = board[row];
    if (rowNumbers.every(num => markedNumbers.has(num))) {
      return {
        pattern: 'horizontal',
        numbers: rowNumbers
      };
    }
  }
  
  // Check vertical lines
  for (let col = 0; col < 5; col++) {
    const colNumbers = board.map(row => row[col]);
    if (colNumbers.every(num => markedNumbers.has(num))) {
      return {
        pattern: 'vertical',
        numbers: colNumbers
      };
    }
  }
  
  // Check diagonal (top-left to bottom-right)
  const diagonal1 = board.map((row, index) => row[index]);
  if (diagonal1.every(num => markedNumbers.has(num))) {
    return {
      pattern: 'diagonal',
      numbers: diagonal1
    };
  }
  
  // Check diagonal (top-right to bottom-left)
  const diagonal2 = board.map((row, index) => row[4 - index]);
  if (diagonal2.every(num => markedNumbers.has(num))) {
    return {
      pattern: 'diagonal',
      numbers: diagonal2
    };
  }
  
  // Check full house
  const allNumbers = board.flat();
  if (allNumbers.every(num => markedNumbers.has(num))) {
    return {
      pattern: 'full-house',
      numbers: allNumbers
    };
  }
  
  return null;
}

/**
 * Generates a random number between min and max (inclusive)
 */
export function randomBetween(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

/**
 * Checks if a number exists on a bingo board
 */
export function numberExistsOnBoard(board: number[][], number: number): boolean {
  return board.some(row => row.includes(number));
}

/**
 * Gets all numbers from a bingo board as a flat array
 */
export function getBoardNumbers(board: number[][]): number[] {
  return board.flat();
}

/**
 * Validates a bingo board (5x5 with unique numbers 1-25)
 */
export function validateBingoBoard(board: number[][]): boolean {
  if (board.length !== 5) return false;
  
  const allNumbers = board.flat();
  if (allNumbers.length !== 25) return false;
  
  // Check all numbers are between 1-25
  if (!allNumbers.every(num => num >= 1 && num <= 25)) return false;
  
  // Check all numbers are unique
  const uniqueNumbers = new Set(allNumbers);
  if (uniqueNumbers.size !== 25) return false;
  
  return true;
}
